# screenshots/

No screenshots are included: they must come from a run on the real dataset, and none were available when this package was built.
Create them in one step after training:

```
pip install playwright
python -m playwright install chromium
uvicorn api.main:app --port 8000          # terminal 1
streamlit run frontend/app.py             # terminal 2
python scripts/capture_screenshots.py     # terminal 3 -> 01..05_*.png here
python -m src.build_docs                  # inserts the gallery into README.md
```
Or take them manually (Windows: `Win+Shift+S`) and save them here as `.png`; `build_docs` lists every PNG in this folder.
(The capture script could not be run in the authoring environment, which has no browser; if a selector fails, use the manual route.)
