"""Smart Accident Alert System - ML package."""
