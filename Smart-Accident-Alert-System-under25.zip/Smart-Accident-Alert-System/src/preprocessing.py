"""Dataset loading, validation, data-quality checks and splitting."""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from src import config as C


class DatasetError(RuntimeError):
    """Raised when the dataset file is missing or does not match expectations."""


def _normalise_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]
    # apply an alias only if the target name is not already present (avoids duplicate columns)
    return df.rename(columns={k: v for k, v in C.COLUMN_ALIASES.items()
                              if k in df.columns and v not in df.columns})


def load_dataset(path: Path | str = C.DATASET_PATH, sample: int | None = None) -> pd.DataFrame:
    """Load a STATS19 collision CSV into ``RAW_FEATURES`` + ``severity``.

    Raises DatasetError with an actionable message instead of guessing.
    ``sample`` (optional) draws a reproducible random subset for quick runs.
    """
    path = Path(path)
    if not path.exists():
        raise DatasetError(
            f"Dataset not found at {path}. Follow dataset/README.md to download the "
            "DfT STATS19 collision CSV and save it there (or set DATASET_PATH)."
        )
    raw = _normalise_columns(pd.read_csv(path, low_memory=False))

    needed = [C.TARGET_SOURCE_COLUMN, "date", "time"] + [
        c for c in C.RAW_FEATURES if c not in ("hour", "month")]
    absent = [c for c in needed if c not in raw.columns]
    if absent:
        raise DatasetError(
            f"Columns missing from {path.name}: {absent}. Available columns: {list(raw.columns)}. "
            "Update src/config.py (COLUMN_ALIASES / feature lists) to match your file."
        )

    df = pd.DataFrame(index=raw.index)
    if "collision_index" in raw.columns:
        df["collision_index"] = raw["collision_index"]
    t = pd.to_datetime(raw["time"], format="%H:%M", errors="coerce")
    df["hour"] = t.dt.hour
    df["month"] = pd.to_datetime(raw["date"], dayfirst=True, errors="coerce").dt.month
    for col in C.RAW_FEATURES:
        if col not in df.columns:
            df[col] = pd.to_numeric(raw[col], errors="coerce")

    code = pd.to_numeric(raw[C.TARGET_SOURCE_COLUMN], errors="coerce")
    df["severity_code"] = code
    df[C.TARGET] = code.map(C.SEVERITY_MAP)
    df.attrs["unmapped_severity_rows"] = int(df[C.TARGET].isna().sum())
    df = df.dropna(subset=[C.TARGET]).reset_index(drop=True)
    if df.empty:
        raise DatasetError("No rows with a valid severity label (expected codes 1, 2, 3).")
    if sample and sample < len(df):
        df = df.sample(sample, random_state=C.RANDOM_STATE).reset_index(drop=True)
    return df


def split_data(df: pd.DataFrame, test_size: float = C.TEST_SIZE, seed: int = C.RANDOM_STATE):
    """Stratified train/test split. Returns X_train, X_test, y_train, y_test."""
    X, y = df[C.RAW_FEATURES], df[C.TARGET]
    return train_test_split(X, y, test_size=test_size, random_state=seed, stratify=y)


def find_unlisted_codes(df: pd.DataFrame) -> dict[str, list[int]]:
    """Codes present in the data that are neither labelled nor marked unknown in config."""
    problems: dict[str, list[int]] = {}
    for col, labels in C.FEATURE_CODES.items():
        known = set(labels) | set(C.UNKNOWN_CODES.get(col, []))
        seen = pd.to_numeric(df[col], errors="coerce").dropna().astype(int).unique()
        extra = sorted(int(v) for v in seen if v not in known)
        if extra:
            problems[col] = extra
    seen = pd.to_numeric(df["speed_limit"], errors="coerce").dropna().astype(int).unique()
    extra = sorted(int(v) for v in seen
                   if v not in C.VALID_SPEED_LIMITS and v not in C.UNKNOWN_CODES["speed_limit"])
    if extra:
        problems["speed_limit"] = extra
    return problems


def data_quality_summary(df: pd.DataFrame) -> dict:
    """Shape, dtypes, missing/unknown counts, duplicates, target distribution."""
    from src.feature_engineering import FeatureEngineer

    cleaned = FeatureEngineer().transform(df[C.RAW_FEATURES])
    counts = df[C.TARGET].value_counts().reindex(C.CLASS_ORDER).fillna(0).astype(int)
    feat_dups = int(df[C.RAW_FEATURES].duplicated().sum())
    return {
        "rows": int(len(df)),
        "columns": int(df.shape[1]),
        "dtypes": {c: str(t) for c, t in df.dtypes.items()},
        "missing_or_unknown_per_feature": {
            c: int(cleaned[c].isna().sum()) for c in C.MODEL_NUMERIC + C.CODE_FEATURES},
        "duplicate_collision_index": (int(df["collision_index"].duplicated().sum())
                                      if "collision_index" in df else None),
        "duplicate_feature_rows": feat_dups,
        "class_counts": counts.to_dict(),
        "class_percent": (counts / counts.sum() * 100).round(2).to_dict(),
        "unmapped_severity_rows_dropped": int(df.attrs.get("unmapped_severity_rows", 0)),
        "unlisted_codes": find_unlisted_codes(df),
    }
