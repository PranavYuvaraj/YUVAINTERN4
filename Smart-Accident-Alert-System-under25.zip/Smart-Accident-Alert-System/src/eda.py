"""Exploratory data analysis. Writes figures and reports/eda_findings.md.

Every statement is computed from the loaded dataset; nothing is pre-written.
Usage: python -m src.eda [--data PATH]
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src import config as C
from src.feature_engineering import FeatureEngineer
from src.preprocessing import data_quality_summary, load_dataset

MIN_N = 200  # minimum category size for ranking statements (lowered automatically for small datasets)


def _save(fig, name):
    C.FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    fig.tight_layout(); fig.savefig(C.FIGURES_DIR / name, dpi=130); plt.close(fig)


def _rates(df, col):
    g = df.groupby(col)[C.TARGET].value_counts().unstack(fill_value=0).reindex(columns=C.CLASS_ORDER, fill_value=0)
    g["n"] = g.sum(axis=1)
    g["high_pct"] = g["High"] / g["n"] * 100
    g["mod_high_pct"] = (g["High"] + g["Moderate"]) / g["n"] * 100
    return g


def run(df: pd.DataFrame) -> str:
    q = data_quality_summary(df)
    clean = FeatureEngineer().transform(df[C.RAW_FEATURES])
    clean[C.TARGET] = df[C.TARGET].values
    n = len(df)
    min_n = min(MIN_N, max(30, n // 50))
    overall_high = (df[C.TARGET] == "High").mean() * 100
    overall_mh = (df[C.TARGET].isin(["High", "Moderate"])).mean() * 100
    md = ["# EDA findings\n", f"_All values computed from the loaded dataset ({n:,} rows)._\n"]

    # 1 structure & quality
    md += ["## 1. Dataset structure and quality\n",
           f"- Shape: **{n:,} rows x {df.shape[1]} columns** (model inputs: {len(C.RAW_FEATURES)} features + target).",
           f"- Duplicate `collision_index` values: {q['duplicate_collision_index']}. Rows with identical feature values "
           f"(different collisions that look alike): {q['duplicate_feature_rows']:,} ({q['duplicate_feature_rows'] / n:.1%}); "
           "these are expected with categorical road/weather features and are kept.",
           f"- Rows dropped for unmapped severity label: {q['unmapped_severity_rows_dropped']}.",
           f"- Unlisted category codes found: {q['unlisted_codes'] or 'none'}.", "",
           "| Feature | dtype | Missing/unknown | % |", "|---|---|---|---|"]
    for c in C.MODEL_NUMERIC + C.CODE_FEATURES:
        m = q["missing_or_unknown_per_feature"][c]
        md.append(f"| {c} | {df[c].dtype} | {m:,} | {m / n:.2%} |")
    miss = pd.Series(q["missing_or_unknown_per_feature"]).sort_values()
    fig, ax = plt.subplots(figsize=(7, 4)); (miss / n * 100).plot.barh(ax=ax, color="#c0392b")
    ax.set_xlabel("% missing or coded unknown"); ax.set_title("Missing / unknown values per feature"); _save(fig, "missing_values.png")
    worst = miss.idxmax()
    md += ["", "![missing](figures/missing_values.png)", "",
           f"**What it shows / why it matters:** unknown codes (-1, 9, 99 ...) were converted to missing. The highest share is "
           f"`{worst}` at {miss.max() / n:.2%}. Because missingness is small or moderate, median/most-frequent imputation "
           "(fitted on training data only) is used instead of dropping rows, which would shrink the rarest class further.\n"]

    # 2 target
    cnt = pd.Series(q["class_counts"]); pct = pd.Series(q["class_percent"])
    fig, ax = plt.subplots(figsize=(5, 4)); ax.bar(cnt.index, cnt.values, color=["#2ecc71", "#f39c12", "#e74c3c"])
    for i, v in enumerate(cnt.values): ax.text(i, v, f"{v:,}\n({pct.iloc[i]:.1f}%)", ha="center", va="bottom")
    ax.set_title("Severity class distribution"); ax.set_ylim(0, cnt.max() * 1.2); _save(fig, "target_distribution.png")
    ratio = cnt.max() / max(cnt.min(), 1)
    md += ["## 2. Target distribution\n", "![target](figures/target_distribution.png)", "",
           "| Class | Count | % |", "|---|---|---|"] + [f"| {c} | {cnt[c]:,} | {pct[c]:.2f}% |" for c in C.CLASS_ORDER] + [
           "", f"**Observation:** the largest class is {ratio:.1f}x the size of the smallest. A classifier that always predicts "
           f"`{cnt.idxmax()}` would reach {cnt.max() / n:.1%} accuracy while detecting no {cnt.idxmin()} cases. "
           "**Impact on modelling:** stratified splits, class-weighted learning and macro-F1/recall (not accuracy) for model selection.\n"]

    # 3 numeric distributions
    fig, axes = plt.subplots(1, 4, figsize=(15, 3.5))
    for ax, c in zip(axes, C.MODEL_NUMERIC):
        clean[c].dropna().plot.hist(ax=ax, bins=min(30, int(clean[c].nunique()) or 10), color="#34495e"); ax.set_title(c)
    _save(fig, "numeric_distributions.png")
    raw_v = pd.to_numeric(df["number_of_vehicles"], errors="coerce")
    p99 = raw_v.quantile(0.99); capped = int((raw_v > C.MAX_VEHICLES_CAP).sum())
    md += ["## 3. Numeric feature distributions and outliers\n", "![num](figures/numeric_distributions.png)", "",
           "| Feature | min | median | mean | p99 | max |", "|---|---|---|---|---|---|"]
    for c in C.MODEL_NUMERIC:
        s = clean[c] if c != "number_of_vehicles" else raw_v.where(raw_v >= 1)
        md.append(f"| {c} | {s.min():.0f} | {s.median():.0f} | {s.mean():.2f} | {s.quantile(.99):.0f} | {s.max():.0f} |")
    md += ["", f"**Outliers:** number_of_vehicles has p99 = {p99:.0f} and max = {raw_v.max():.0f}; the pipeline caps it at "
           f"{C.MAX_VEHICLES_CAP}, affecting {capped:,} rows ({capped / n:.3%}). If this share looks material, change "
           "`MAX_VEHICLES_CAP` in `src/config.py` and retrain.\n"]

    # 4 severity by categorical features
    md += ["## 4. Severity rate by feature\n",
           f"Overall: High = {overall_high:.2f}%, Moderate+High = {overall_mh:.2f}%. Categories with n < {min_n} are not ranked.\n"]
    for c in ["speed_limit", "light_conditions", "road_type", "urban_or_rural_area", "road_surface_conditions",
              "weather_conditions", "junction_detail"]:
        g = _rates(clean.assign(**{c: clean[c]}), c)
        g = g[g["n"] >= min_n]
        if g.empty:
            continue
        lab = C.FEATURE_CODES.get(c, {})
        names = [lab.get(int(i), str(int(i))) for i in g.index]
        fig, ax = plt.subplots(figsize=(7, max(2.5, 0.4 * len(g))))
        (g[C.CLASS_ORDER].div(g["n"], axis=0) * 100).set_axis(names).plot.barh(
            stacked=True, ax=ax, color=["#2ecc71", "#f39c12", "#e74c3c"]); ax.set_xlabel("% of collisions")
        ax.set_title(f"Severity mix by {c}"); _save(fig, f"severity_by_{c}.png")
        hi, lo = g["high_pct"].idxmax(), g["high_pct"].idxmin()
        L = lambda k: lab.get(int(k), str(int(k)))
        md += [f"### {c}\n", f"![{c}](figures/severity_by_{c}.png)", "",
               f"**Observed:** highest High-severity share is **{L(hi)}** at {g.loc[hi, 'high_pct']:.2f}% (n={int(g.loc[hi, 'n']):,}); "
               f"lowest is **{L(lo)}** at {g.loc[lo, 'high_pct']:.2f}% (n={int(g.loc[lo, 'n']):,}); overall {overall_high:.2f}%. "
               f"That is a {g.loc[hi, 'high_pct'] / max(g.loc[lo, 'high_pct'], 1e-9):.1f}x spread. "
               "**Why it matters:** a wide spread means the feature separates classes and is worth keeping; a narrow spread "
               "means weak signal. The model uses it as a one-hot / numeric input accordingly.\n"]

    # 5 time
    h = _rates(clean.dropna(subset=["hour"]), "hour"); h = h[h["n"] >= min_n]
    if h.empty:
        md += ["## 5. Time of day\n", f"No hour has at least {min_n} collisions; hourly statistics skipped.\n"]
    else:
        fig, ax = plt.subplots(figsize=(8, 3.5)); ax.plot(h.index, h["high_pct"], marker="o", color="#e74c3c", label="High %")
        ax.plot(h.index, h["mod_high_pct"], marker="s", color="#f39c12", label="Moderate+High %"); ax.set_xlabel("hour"); ax.legend()
        ax.set_title("Severity share by hour of day"); _save(fig, "severity_by_hour.png")
        md += ["## 5. Time of day\n", "![hour](figures/severity_by_hour.png)", "",
               f"**Observed:** High share peaks at hour {int(h['high_pct'].idxmax())}:00 ({h['high_pct'].max():.2f}%, n={int(h.loc[h['high_pct'].idxmax(), 'n']):,}) "
               f"and is lowest at {int(h['high_pct'].idxmin())}:00 ({h['high_pct'].min():.2f}%). Collision volume peaks at "
               f"{int(h['n'].idxmax())}:00 ({int(h['n'].max()):,} collisions), i.e. the busiest hour is not necessarily the most severe. "
               "**Influence:** motivates the engineered `is_night`, `is_rush_hour` and `is_weekend` flags.\n"]


    # 6 correlation
    num = clean[C.MODEL_NUMERIC + ["is_weekend", "is_rush_hour", "is_night"]].copy()
    num["severity_ordinal"] = df[C.TARGET].map({"Low": 0, "Moderate": 1, "High": 2}).values
    corr = num.corr(method="spearman")
    fig, ax = plt.subplots(figsize=(7, 6)); im = ax.imshow(corr, cmap="coolwarm", vmin=-1, vmax=1)
    ax.set_xticks(range(len(corr)), corr.columns, rotation=60, ha="right"); ax.set_yticks(range(len(corr)), corr.columns)
    for i in range(len(corr)):
        for j in range(len(corr)): ax.text(j, i, f"{corr.iloc[i, j]:.2f}", ha="center", va="center", fontsize=7)
    fig.colorbar(im); ax.set_title("Spearman correlation"); _save(fig, "correlation_heatmap.png")
    sev = corr["severity_ordinal"].drop("severity_ordinal").sort_values(key=abs, ascending=False)
    md += ["## 6. Correlation\n", "![corr](figures/correlation_heatmap.png)", "",
           "**Observed (Spearman correlation with ordinal severity Low<Moderate<High):** "
           + ", ".join(f"{k} {v:+.3f}" for k, v in sev.head(4).items()) + ". "
           "Absolute values near 0 mean no monotonic relationship; non-monotonic effects (e.g. hour) can still matter, which is why "
           "tree-based models are compared against the linear baseline.\n"]

    # 7 relationship: speed x urban/rural
    cross = clean.dropna(subset=["speed_limit", "urban_or_rural_area"]).copy()
    pv = cross.assign(high=(cross[C.TARGET] == "High") * 100).pivot_table(
        index="speed_limit", columns="urban_or_rural_area", values="high", aggfunc="mean")
    pv.columns = [C.FEATURE_CODES["urban_or_rural_area"].get(int(c), c) for c in pv.columns]
    md += ["## 7. Relationship: speed limit x urban/rural (High-severity %)\n", pv.round(2).to_markdown(), "",
           "**Why it matters:** if the High share differs by area type *within* the same speed limit, the two features carry "
           "partly independent information and an interaction-capable model (tree/forest) may help.\n"]

    text = "\n".join(md)
    C.REPORTS_DIR.mkdir(exist_ok=True)
    (C.REPORTS_DIR / "eda_findings.md").write_text(text, encoding="utf-8")
    (C.REPORTS_DIR / "eda_stats.json").write_text(json.dumps(
        {"rows": n, "class_counts": q["class_counts"], "class_percent": q["class_percent"],
         "missing": q["missing_or_unknown_per_feature"], "duplicate_feature_rows": q["duplicate_feature_rows"]}, indent=2))
    return text


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--data", default=str(C.DATASET_PATH))
    ap.add_argument("--sample", type=int, default=None); a = ap.parse_args()
    run(load_dataset(Path(a.data), sample=a.sample)); print(f"Wrote {C.REPORTS_DIR / 'eda_findings.md'}")


if __name__ == "__main__":
    main()
