"""Train, tune, compare, select, serialise and verify the severity model.

Usage:  python -m src.train [--data PATH] [--sample N] [--tune-rows N]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import time
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

from src import config as C
from src.evaluate import compute_metrics, write_model_evaluation
from src.feature_engineering import FeatureEngineer
from src.preprocessing import data_quality_summary, load_dataset, split_data


def build_pipeline(estimator) -> Pipeline:
    prep = ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), C.MODEL_NUMERIC),
        ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                          ("oh", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]), C.MODEL_CATEGORICAL),
    ])
    return Pipeline([("features", FeatureEngineer()), ("prep", prep), ("clf", estimator)])


def candidate_models() -> dict:
    rs = C.RANDOM_STATE
    return {
        "Logistic Regression": (LogisticRegression(max_iter=1000, class_weight="balanced"),
                                {"clf__C": [0.1, 1.0, 10.0]}),
        "Decision Tree": (DecisionTreeClassifier(class_weight="balanced", random_state=rs),
                          {"clf__max_depth": [5, 8, 12], "clf__min_samples_leaf": [20, 50, 100]}),
        "Random Forest": (RandomForestClassifier(class_weight="balanced_subsample", random_state=rs, n_jobs=-1),
                          {"clf__n_estimators": [100, 200], "clf__max_depth": [10, 16],
                           "clf__min_samples_leaf": [5, 20]}),
    }


def _sha256(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _identical_pct(X_train, X_test) -> float:
    fe = FeatureEngineer()
    a = fe.transform(X_train).fillna(-999).round(3).astype(str).agg("|".join, axis=1)
    b = fe.transform(X_test).fillna(-999).round(3).astype(str).agg("|".join, axis=1)
    return float(b.isin(set(a)).mean() * 100)


def train(data_path=C.DATASET_PATH, sample=None, tune_rows=30000, cv_folds=3,
          model_path=C.MODEL_PATH, metadata_path=C.METADATA_PATH, write_reports=True, verbose=True):
    log = print if verbose else (lambda *a, **k: None)
    df = load_dataset(data_path, sample=sample)
    quality = data_quality_summary(df)
    log(f"Loaded {quality['rows']:,} rows; class counts {quality['class_counts']}")
    if quality["unlisted_codes"]:
        log(f"WARNING codes not in src/config.py (check field guide): {quality['unlisted_codes']}")

    X_train, X_test, y_train, y_test = split_data(df)
    if len(X_train) > tune_rows:  # tune on a stratified subsample for speed; refit on all training rows
        X_tune, _, y_tune, _ = train_test_split(X_train, y_train, train_size=tune_rows,
                                                random_state=C.RANDOM_STATE, stratify=y_train)
    else:
        X_tune, y_tune = X_train, y_train
    cv = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=C.RANDOM_STATE)

    results, fitted = {}, {}
    base = build_pipeline(DummyClassifier(strategy="most_frequent")).fit(X_train, y_train)
    results["Baseline (most frequent)"] = {"test": compute_metrics(base, X_test, y_test),
                                           "train_macro_f1": compute_metrics(base, X_train, y_train)["macro_f1"],
                                           "cv_macro_f1_mean": None, "cv_macro_f1_std": None, "best_params": None}
    for name, (est, grid) in candidate_models().items():
        t0 = time.time()
        gs = GridSearchCV(build_pipeline(est), grid, scoring="f1_macro", cv=cv, n_jobs=1, refit=True)
        gs.fit(X_tune, y_tune)
        best = build_pipeline(est).set_params(**gs.best_params_).fit(X_train, y_train)
        i = gs.best_index_
        results[name] = {
            "best_params": {k.replace("clf__", ""): v for k, v in gs.best_params_.items()},
            "cv_macro_f1_mean": float(gs.cv_results_["mean_test_score"][i]),
            "cv_macro_f1_std": float(gs.cv_results_["std_test_score"][i]),
            "train_macro_f1": compute_metrics(best, X_train, y_train)["macro_f1"],
            "test": compute_metrics(best, X_test, y_test),
            "fit_seconds": round(time.time() - t0, 1),
        }
        fitted[name] = best
        log(f"{name}: CV macro-F1 {results[name]['cv_macro_f1_mean']:.3f} | test macro-F1 "
            f"{results[name]['test']['macro_f1']:.3f} ({results[name]['fit_seconds']}s)")

    selected = max(fitted, key=lambda n: results[n]["cv_macro_f1_mean"])  # test set not used to choose
    pipe = fitted[selected]

    model_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(pipe, model_path, compress=3)
    reloaded = joblib.load(model_path)
    sample_X = X_test.head(500)
    same_labels = bool((reloaded.predict(sample_X) == pipe.predict(sample_X)).all())
    same_proba = bool(np.allclose(reloaded.predict_proba(sample_X), pipe.predict_proba(sample_X)))
    if not (same_labels and same_proba):
        raise RuntimeError("Reloaded model does not reproduce the original predictions.")
    log(f"Saved {model_path} ({model_path.stat().st_size / 1e6:.1f} MB); reload check passed.")

    cls_pct = (y_test.value_counts(normalize=True) * 100).reindex(C.CLASS_ORDER).round(2).to_dict()
    meta = {
        "model_name": selected, "selection_rule": "highest cross-validated macro-F1 on training data",
        "classes": C.CLASS_ORDER, "severity_mapping": {str(k): v for k, v in C.SEVERITY_MAP.items()},
        "features": C.RAW_FEATURES, "numeric_features": C.NUMERIC_FEATURES, "categorical_features": C.CODE_FEATURES,
        "trained_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
        "dataset_file": str(getattr(data_path, "name", data_path)), "dataset_sha256": _sha256(data_path),
        "n_rows": quality["rows"], "n_train": int(len(X_train)), "n_test": int(len(X_test)),
        "class_percent_test": cls_pct, "tuning_rows": int(len(X_tune)), "cv_folds": cv_folds,
        "best_params": results[selected]["best_params"],
        "metrics": {n: r["test"] for n, r in results.items()},
        "cv_macro_f1": {n: r["cv_macro_f1_mean"] for n, r in results.items()},
        "train_macro_f1": {n: r["train_macro_f1"] for n, r in results.items()},
        "reload_verified": {"labels_identical": same_labels, "probabilities_close": same_proba},
        "test_rows_identical_to_train_pct": _identical_pct(X_train, X_test),
        "versions": {"python": platform.python_version(), "scikit-learn": sklearn.__version__,
                     "pandas": pd.__version__, "joblib": joblib.__version__},
        "data_quality": quality, "disclaimer": C.DISCLAIMER,
    }
    if write_reports:
        write_model_evaluation(results, selected, meta, pipe, X_test, y_test)
        C.REPORTS_DIR.mkdir(exist_ok=True)
        (C.REPORTS_DIR / "metrics.json").write_text(json.dumps({"results": results, "selected": selected}, indent=2))
    metadata_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    log(f"Selected: {selected}. Reports written to {C.REPORTS_DIR}.")
    return pipe, meta, results


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--data", default=str(C.DATASET_PATH))
    ap.add_argument("--sample", type=int, default=None, help="use a random subset (quick runs)")
    ap.add_argument("--tune-rows", type=int, default=30000)
    a = ap.parse_args()
    from pathlib import Path
    train(Path(a.data), sample=a.sample, tune_rows=a.tune_rows)


if __name__ == "__main__":
    main()
