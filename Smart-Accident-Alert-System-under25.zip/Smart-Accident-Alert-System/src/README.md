# src/ - ML code
| Module | Role |
|---|---|
| `config.py` | Paths, label map, feature lists, code tables (single source of truth; check against the DfT data guide) |
| `preprocessing.py` | Load/validate STATS19 CSV, header aliases, label mapping, quality summary, stratified split |
| `feature_engineering.py` | Stateless cleaning + time flags, inside the saved pipeline |
| `train.py` | Grid search, model comparison, selection, Joblib save + reload check |
| `evaluate.py` | Metrics, figures, `reports/model_evaluation.md`, worked example |
| `eda.py` | Figures and data-driven `reports/eda_findings.md` |
| `predict.py` | Load model, predict one record (used by the API) |
| `build_docs.py` | Fills README results/screenshots, project report, slides, Q&A from real artifacts |

Run from the repository root with `python -m src.<module>`.
