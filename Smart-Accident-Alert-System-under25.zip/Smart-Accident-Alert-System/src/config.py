"""Central configuration: paths, label mapping and feature definitions.

Every other module (training, API, dashboard, tests) imports from here, so the
model, the API schema and the UI cannot drift apart.

IMPORTANT: the code tables below follow the UK DfT STATS19 collision field
guide. They MUST be checked against the field guide that ships with the
dataset file you download. ``python -m src.train`` prints any code found in the
data that is not listed here (see ``preprocessing.find_unlisted_codes``).
"""
from __future__ import annotations

import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

DATASET_PATH = Path(os.getenv("DATASET_PATH", ROOT / "dataset" / "accident_data.csv"))
MODEL_PATH = Path(os.getenv("MODEL_PATH", ROOT / "models" / "accident_severity_model.joblib"))
METADATA_PATH = Path(os.getenv("MODEL_METADATA_PATH", ROOT / "models" / "model_metadata.json"))
REPORTS_DIR = ROOT / "reports"
FIGURES_DIR = REPORTS_DIR / "figures"

RANDOM_STATE = 42
TEST_SIZE = 0.20

# --------------------------------------------------------------------------
# Target: STATS19 collision_severity (1 Fatal, 2 Serious, 3 Slight).
# One-to-one rename onto the project's three classes; nothing is merged.
# --------------------------------------------------------------------------
SEVERITY_MAP = {1: "High", 2: "Moderate", 3: "Low"}
CLASS_ORDER = ["Low", "Moderate", "High"]  # ordinal order used everywhere
TARGET_SOURCE_COLUMN = "collision_severity"
TARGET = "severity"

# Older STATS19 files use different headers; names are lower-cased first.
COLUMN_ALIASES = {
    "accident_severity": "collision_severity",
    # Newer DfT files (2024+) list "legacy_collision_severity" (1 Fatal, 2 Serious, 3 Slight)
    # next to "enhanced_severity_collision". Verify in the data guide before using them.
    "legacy_collision_severity": "collision_severity",
    "accident_index": "collision_index",
    "number_of_casualties": "number_of_casualties",
    "1st_road_class": "first_road_class",
}

# --------------------------------------------------------------------------
# Features. Only information that someone could know at report time is used.
# Deliberately EXCLUDED (post-outcome or identifying):
#   number_of_casualties, did_police_officer_attend_scene_of_accident,
#   latitude/longitude/easting/northing, police_force, LSOA, vehicle & casualty
#   tables (not known at alert time), collision_index (identifier).
# --------------------------------------------------------------------------
NUMERIC_FEATURES = ["speed_limit", "number_of_vehicles", "hour", "month"]
CODE_FEATURES = [  # integer-coded categories
    "day_of_week",
    "road_type",
    "junction_detail",
    "first_road_class",
    "light_conditions",
    "weather_conditions",
    "road_surface_conditions",
    "urban_or_rural_area",
]
RAW_FEATURES = NUMERIC_FEATURES + CODE_FEATURES  # what the API sends / the pipeline receives
ENGINEERED_FLAGS = ["is_weekend", "is_rush_hour", "is_night"]  # created in FeatureEngineer
MODEL_NUMERIC = NUMERIC_FEATURES
MODEL_CATEGORICAL = CODE_FEATURES + ENGINEERED_FLAGS

# Outlier handling: number_of_vehicles is capped (winsorised) at this value.
# Review against reports/eda_findings.md after the first EDA run.
MAX_VEHICLES_CAP = 10

VALID_SPEED_LIMITS = [20, 30, 40, 50, 60, 70]
HOUR_RANGE = (0, 23)
MONTH_RANGE = (1, 12)
VEHICLES_RANGE = (1, 50)

# Value labels (also drive the dashboard drop-downs).
FEATURE_CODES: dict[str, dict[int, str]] = {
    "day_of_week": {1: "Sunday", 2: "Monday", 3: "Tuesday", 4: "Wednesday",
                    5: "Thursday", 6: "Friday", 7: "Saturday"},
    "road_type": {1: "Roundabout", 2: "One way street", 3: "Dual carriageway",
                  6: "Single carriageway", 7: "Slip road", 12: "One way street/Slip road"},
    "junction_detail": {0: "Not at junction or within 20 m", 1: "Roundabout",
                        2: "Mini-roundabout", 3: "T or staggered junction", 5: "Slip road",
                        6: "Crossroads", 7: "More than 4 arms (not roundabout)",
                        8: "Private drive or entrance", 9: "Other junction"},
    "first_road_class": {1: "Motorway", 2: "A(M)", 3: "A road", 4: "B road",
                         5: "C road", 6: "Unclassified"},
    "light_conditions": {1: "Daylight", 4: "Darkness - lights lit", 5: "Darkness - lights unlit",
                         6: "Darkness - no lighting", 7: "Darkness - lighting unknown"},
    "weather_conditions": {1: "Fine, no high winds", 2: "Raining, no high winds",
                           3: "Snowing, no high winds", 4: "Fine, high winds",
                           5: "Raining, high winds", 6: "Snowing, high winds",
                           7: "Fog or mist", 8: "Other"},
    "road_surface_conditions": {1: "Dry", 2: "Wet or damp", 3: "Snow", 4: "Frost or ice",
                                5: "Flood over 3 cm deep", 6: "Oil or diesel", 7: "Mud"},
    "urban_or_rural_area": {1: "Urban", 2: "Rural"},
}

# Codes that mean "unknown / not recorded" -> converted to NaN, then imputed.
UNKNOWN_CODES: dict[str, list[int]] = {
    "speed_limit": [-1, 99],
    "number_of_vehicles": [-1],
    "road_type": [-1, 9],
    "junction_detail": [-1, 99],
    "first_road_class": [-1],
    "light_conditions": [-1],
    "weather_conditions": [-1, 9],
    "road_surface_conditions": [-1, 9],
    "urban_or_rural_area": [-1, 3],
    "day_of_week": [-1],
}

FEATURE_DESCRIPTIONS = {
    "speed_limit": "Posted speed limit (mph)",
    "number_of_vehicles": "Number of vehicles involved",
    "hour": "Hour of day (0-23)",
    "month": "Month of year (1-12)",
    "day_of_week": "Day of week",
    "road_type": "Road type",
    "junction_detail": "Junction detail",
    "first_road_class": "Class of first road",
    "light_conditions": "Light conditions",
    "weather_conditions": "Weather conditions",
    "road_surface_conditions": "Road surface conditions",
    "urban_or_rural_area": "Urban or rural area",
}

# Fields the API requires; the rest may be omitted and are imputed with the
# training-set median / most frequent value (the response lists them).
REQUIRED_API_FIELDS = [
    "speed_limit", "hour", "road_type", "light_conditions",
    "weather_conditions", "road_surface_conditions", "urban_or_rural_area",
]

DISCLAIMER = (
    "Educational prototype. Predictions are statistical estimates from road and "
    "environment conditions, are not validated for safety use, and must never "
    "trigger emergency dispatch without human verification."
)
