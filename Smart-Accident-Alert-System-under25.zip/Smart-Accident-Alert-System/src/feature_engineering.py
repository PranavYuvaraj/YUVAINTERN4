"""Feature cleaning/engineering as a scikit-learn transformer.

It lives INSIDE the saved pipeline, so training and the API apply exactly the
same logic (no train/serve skew). It is stateless: nothing is learned from the
data, therefore it cannot leak information from the test set.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

from src import config as C


class FeatureEngineer(BaseEstimator, TransformerMixin):
    """Clean raw feature columns and add simple time-based flags.

    Steps: numeric coercion -> unknown codes to NaN -> range checks ->
    cap number_of_vehicles (outlier handling) -> add is_weekend / is_rush_hour
    / is_night. Imputation and encoding happen later in the pipeline.
    """

    def __init__(self, max_vehicles: int = C.MAX_VEHICLES_CAP):
        self.max_vehicles = max_vehicles

    def fit(self, X, y=None):
        self.n_features_in_ = len(C.RAW_FEATURES)
        return self

    def transform(self, X) -> pd.DataFrame:
        df = X if isinstance(X, pd.DataFrame) else pd.DataFrame(X, columns=C.RAW_FEATURES)
        missing = [c for c in C.RAW_FEATURES if c not in df.columns]
        if missing:
            raise ValueError(f"Missing required feature columns: {missing}")
        out = df[C.RAW_FEATURES].apply(pd.to_numeric, errors="coerce").astype("float64")

        for col, codes in C.UNKNOWN_CODES.items():
            out[col] = out[col].mask(out[col].isin(codes))
        out["hour"] = out["hour"].where(out["hour"].between(*C.HOUR_RANGE))
        out["month"] = out["month"].where(out["month"].between(*C.MONTH_RANGE))
        out["number_of_vehicles"] = out["number_of_vehicles"].where(out["number_of_vehicles"] >= 1)
        out["number_of_vehicles"] = out["number_of_vehicles"].clip(upper=self.max_vehicles)

        hour, dow = out["hour"], out["day_of_week"]
        out["is_weekend"] = dow.isin([1, 7]).astype("float64").where(dow.notna())
        out["is_rush_hour"] = (hour.between(7, 9) | hour.between(16, 18)).astype("float64").where(hour.notna())
        out["is_night"] = ((hour >= 22) | (hour <= 4)).astype("float64").where(hour.notna())
        return out[C.MODEL_NUMERIC + C.MODEL_CATEGORICAL]

    def get_feature_names_out(self, input_features=None):
        return np.array(C.MODEL_NUMERIC + C.MODEL_CATEGORICAL)
