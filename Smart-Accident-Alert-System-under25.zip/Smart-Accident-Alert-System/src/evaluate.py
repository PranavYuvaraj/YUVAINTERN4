"""Evaluation: metrics from real predictions, figures and the evaluation report.

Nothing here contains hard-coded results. Every number written to
reports/model_evaluation.md and reports/worked_example.md is computed from the
fitted models and the held-out test set at run time.
"""
from __future__ import annotations

import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, confusion_matrix,
                             precision_recall_fscore_support, roc_auc_score)
from sklearn.preprocessing import label_binarize

from src import config as C

LABELS = C.CLASS_ORDER


def _proba_in_order(pipe, X) -> np.ndarray:
    proba = pipe.predict_proba(X)
    idx = [list(pipe.classes_).index(c) for c in LABELS]
    return proba[:, idx]


def compute_metrics(pipe, X, y) -> dict:
    """Accuracy, macro/per-class precision-recall-F1, confusion matrix, ROC-AUC (OvR)."""
    pred = pipe.predict(X)
    p, r, f, s = precision_recall_fscore_support(y, pred, labels=LABELS, zero_division=0)
    mp, mr, mf, _ = precision_recall_fscore_support(y, pred, labels=LABELS, average="macro", zero_division=0)
    out = {
        "accuracy": float(accuracy_score(y, pred)),
        "balanced_accuracy": float(balanced_accuracy_score(y, pred)),
        "macro_precision": float(mp), "macro_recall": float(mr), "macro_f1": float(mf),
        "per_class": {c: {"precision": float(p[i]), "recall": float(r[i]),
                          "f1": float(f[i]), "support": int(s[i])} for i, c in enumerate(LABELS)},
        "confusion_matrix": confusion_matrix(y, pred, labels=LABELS).tolist(),
        "roc_auc_ovr_macro": None, "roc_auc_per_class": {},
    }
    try:
        proba = _proba_in_order(pipe, X)
        yb = label_binarize(y, classes=LABELS)
        out["roc_auc_ovr_macro"] = float(roc_auc_score(yb, proba, average="macro"))
        out["roc_auc_per_class"] = {c: float(roc_auc_score(yb[:, i], proba[:, i]))
                                    for i, c in enumerate(LABELS)}
    except ValueError:  # e.g. a class missing from y
        pass
    return out


# ----------------------------------------------------------------- figures
def plot_confusion(cm, title: str, path) -> None:
    cm = np.array(cm)
    norm = cm / cm.sum(axis=1, keepdims=True).clip(min=1)
    fig, axes = plt.subplots(1, 2, figsize=(10, 4))
    for ax, data, fmt, sub in ((axes[0], cm, "d", "Counts"), (axes[1], norm, ".2f", "Row-normalised (recall)")):
        ax.imshow(data, cmap="Blues")
        ax.set_xticks(range(3), LABELS); ax.set_yticks(range(3), LABELS)
        ax.set_xlabel("Predicted"); ax.set_ylabel("Actual"); ax.set_title(f"{sub}")
        for i in range(3):
            for j in range(3):
                ax.text(j, i, format(data[i, j], fmt), ha="center", va="center",
                        color="white" if data[i, j] > data.max() / 2 else "black")
    fig.suptitle(title); fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def plot_model_comparison(results: dict, path) -> None:
    names = list(results)
    metrics = ["accuracy", "macro_f1", "macro_recall"]
    x = np.arange(len(names)); w = 0.25
    fig, ax = plt.subplots(figsize=(8, 4))
    for k, m in enumerate(metrics):
        ax.bar(x + (k - 1) * w, [results[n]["test"][m] for n in names], w, label=m)
    ax.set_xticks(x, names); ax.set_ylim(0, 1); ax.legend(); ax.set_title("Test-set comparison")
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


# ------------------------------------------------------------------ report
def _fmt(v, d=3):
    return "n/a" if v is None else f"{v:.{d}f}"


def _explain(selected: str, others: dict, sel: dict) -> str:
    lines = []
    for name, res in others.items():
        if name == selected or name == "Baseline (most frequent)":
            continue
        d = sel["test"]["macro_f1"] - res["test"]["macro_f1"]
        dh = sel["test"]["per_class"]["High"]["recall"] - res["test"]["per_class"]["High"]["recall"]
        lines.append(f"- vs **{name}**: test macro-F1 differs by {d:+.3f}; recall on High differs by {dh:+.3f}.")
    general = {
        "Random Forest": ("A forest averages many decorrelated trees, which usually reduces the variance of a "
                          "single tree and can capture interactions (e.g. speed limit x light conditions) that a "
                          "linear model cannot. Whether that happened here is shown by the deltas above."),
        "Decision Tree": ("A single shallow tree is easy to interpret and was tuned for depth/leaf size to limit "
                          "overfitting; the deltas above show whether its simplicity was enough."),
        "Logistic Regression": ("A linear model on one-hot features is stable and fast; if it leads, the signal in "
                                "these features is largely additive and extra model flexibility gave no benefit."),
    }[selected]
    return "\n".join(lines) + f"\n\n{general}"


def pick_examples(pipe, X_test, y_test, n_per_case: int = 1) -> pd.DataFrame:
    """Deterministic real test rows: one correct and one wrong example per true class (if available)."""
    pred = pd.Series(pipe.predict(X_test), index=X_test.index)
    proba = pd.DataFrame(_proba_in_order(pipe, X_test), index=X_test.index, columns=[f"p_{c}" for c in LABELS])
    rows = []
    for cls in LABELS[::-1]:
        for correct in (True, False):
            mask = (y_test == cls) & ((pred == y_test) == correct)
            for idx in y_test[mask].index[:n_per_case]:
                rows.append(idx)
    ex = X_test.loc[rows].copy()
    for col, codes in C.FEATURE_CODES.items():
        ex[col] = ex[col].map(lambda v, codes=codes: codes.get(int(v), "unknown") if pd.notna(v) else "missing")
    ex["actual"] = y_test.loc[rows]
    ex["predicted"] = pred.loc[rows]
    return ex.join(proba.loc[rows].round(3))


def write_worked_example(pipe, X_test, y_test, path) -> dict:
    """Trace one real test record through cleaning, encoding and prediction."""
    pred = pd.Series(pipe.predict(X_test), index=X_test.index)
    ok = y_test[(y_test == "High") & (pred == y_test)]
    idx = (ok.index[0] if len(ok) else y_test.index[0])
    raw = X_test.loc[[idx]]
    cleaned = pipe.named_steps["features"].transform(raw)
    enc = pipe.named_steps["prep"].transform(cleaned)
    names = pipe.named_steps["prep"].get_feature_names_out()
    nz = [(n, float(v)) for n, v in zip(names, np.asarray(enc)[0]) if v != 0]
    proba = dict(zip(LABELS, _proba_in_order(pipe, raw)[0].round(4)))
    md = [
        "# Worked example: one real test record through the pipeline\n",
        f"Row index in the test set: `{idx}` (identifiers, coordinates and police-force fields are not used and not shown).\n",
        "## 1. Raw model inputs (codes as stored in the dataset)\n",
        raw.T.rename(columns={idx: "value"}).to_markdown(), "",
        "## 2. After `FeatureEngineer` (unknown codes -> NaN, vehicle cap, engineered flags)\n",
        cleaned.T.rename(columns={idx: "value"}).to_markdown(), "",
        "## 3. After imputation, scaling and one-hot encoding\n",
        f"{enc.shape[1]} encoded features; the non-zero ones are:\n",
        pd.DataFrame(nz, columns=["encoded_feature", "value"]).to_markdown(index=False), "",
        "## 4. Model output\n",
        f"Class probabilities: `{ {k: float(v) for k, v in proba.items()} }`\n",
        f"- **Predicted:** {pipe.predict(raw)[0]}   - **Actual:** {y_test.loc[idx]}\n",
    ]
    path.write_text("\n".join(md), encoding="utf-8")
    return {"index": int(idx) if str(idx).isdigit() else str(idx), "predicted": str(pipe.predict(raw)[0]),
            "actual": str(y_test.loc[idx])}


def write_model_evaluation(results: dict, selected: str, meta: dict, pipe, X_test, y_test) -> None:
    C.FIGURES_DIR.mkdir(parents=True, exist_ok=True)
    sel = results[selected]
    base = results["Baseline (most frequent)"]
    cm = np.array(sel["test"]["confusion_matrix"])
    plot_confusion(cm, f"{selected} - confusion matrix (test set)", C.FIGURES_DIR / "confusion_matrix.png")
    plot_model_comparison(results, C.FIGURES_DIR / "model_comparison.png")

    md = ["# Model evaluation\n",
          f"_Generated by `src/train.py` on {meta['trained_at']} from `{meta['dataset_file']}` "
          f"(SHA-256 `{meta['dataset_sha256'][:16]}...`). All numbers below are computed from real predictions on a "
          f"stratified hold-out test set of {meta['n_test']:,} rows; training used {meta['n_train']:,} rows._\n",
          "## 1. Model comparison\n",
          "| Model | CV macro-F1 (mean ± std) | Test accuracy | Macro precision | Macro recall | Macro F1 | ROC-AUC (OvR) | Train macro-F1 | Train-test gap |",
          "|---|---|---|---|---|---|---|---|---|"]
    for name, r in results.items():
        t = r["test"]
        cv = "n/a" if r.get("cv_macro_f1_mean") is None else f"{r['cv_macro_f1_mean']:.3f} ± {r['cv_macro_f1_std']:.3f}"
        tr = r.get("train_macro_f1")
        gap = None if tr is None else tr - t["macro_f1"]
        md.append(f"| {name} | {cv} | {_fmt(t['accuracy'])} | {_fmt(t['macro_precision'])} | {_fmt(t['macro_recall'])} | "
                  f"{_fmt(t['macro_f1'])} | {_fmt(t['roc_auc_ovr_macro'])} | {_fmt(tr)} | {_fmt(gap)} |")
    md += ["", "![comparison](figures/model_comparison.png)", "",
           "Best hyper-parameters (found by grid search, scoring = macro-F1, on training data only):\n"]
    for name, r in results.items():
        if r.get("best_params"):
            md.append(f"- **{name}**: `{r['best_params']}`")
    md += ["", f"## 2. Selected model: {selected}\n",
           f"Selection rule: highest cross-validated macro-F1 on the training data (the test set was NOT used to choose). "
           f"{selected} scored {sel['cv_macro_f1_mean']:.3f} in CV and {sel['test']['macro_f1']:.3f} macro-F1 on the test set.\n",
           _explain(selected, results, sel), "",
           "## 3. Class-wise performance (selected model, test set)\n",
           "| Class | Precision | Recall | F1 | Support | ROC-AUC (one-vs-rest) |", "|---|---|---|---|---|---|"]
    for c in LABELS:
        pc = sel["test"]["per_class"][c]
        md.append(f"| {c} | {pc['precision']:.3f} | {pc['recall']:.3f} | {pc['f1']:.3f} | {pc['support']:,} | "
                  f"{_fmt(sel['test']['roc_auc_per_class'].get(c))} |")

    tot = cm.sum(axis=1)
    md += ["", "## 4. Confusion matrix interpretation\n", "![cm](figures/confusion_matrix.png)", "",
           "| Actual \\ Predicted | " + " | ".join(LABELS) + " |", "|---|---|---|---|"]
    for i, c in enumerate(LABELS):
        md.append(f"| **{c}** | " + " | ".join(f"{cm[i, j]:,}" for j in range(3)) + " |")
    hi = LABELS.index("High")
    fn_high = int(cm[hi].sum() - cm[hi, hi])
    fp_high = int(cm[:, hi].sum() - cm[hi, hi])
    md += ["",
           f"- **False negatives for High:** {fn_high:,} of {tot[hi]:,} truly High collisions "
           f"({fn_high / max(tot[hi], 1):.1%}) were predicted as Low or Moderate. These are the costly errors in a "
           "safety setting because a serious case would be under-prioritised.",
           f"- **False positives for High:** {fp_high:,} collisions predicted High were actually Low/Moderate "
           f"(High precision {sel['test']['per_class']['High']['precision']:.1%}). These cost extra attention but are less dangerous.",
           ]
    for i, c in enumerate(LABELS):
        wrong = [(cm[i, j], LABELS[j]) for j in range(3) if j != i]
        n, lab = max(wrong)
        md.append(f"- Actual **{c}**: recall {cm[i, i] / max(tot[i], 1):.1%}; most common error is predicting {lab} ({n:,} cases).")

    pct = meta["class_percent_test"]
    md += ["", "## 5. Class imbalance\n",
           f"Test-set class shares: " + ", ".join(f"{c} {pct[c]:.2f}%" for c in LABELS) + ". "
           f"A model that always predicts the majority class scores accuracy {base['test']['accuracy']:.3f} but macro-F1 "
           f"{base['test']['macro_f1']:.3f}, so accuracy alone is misleading here. "
           f"The selected model's accuracy is {sel['test']['accuracy']:.3f} and macro-F1 {sel['test']['macro_f1']:.3f}. "
           "Mitigations used: stratified split, `class_weight='balanced'` and model selection by macro-F1. "
           "Class weighting typically raises minority-class recall at the cost of precision; compare the per-class table above.\n"]

    gap = sel["train_macro_f1"] - sel["test"]["macro_f1"]
    verdict = ("a large gap, indicating overfitting" if gap > 0.10 else
               "a moderate gap" if gap > 0.03 else "a small gap, so no strong sign of overfitting")
    md += ["## 6. Overfitting / underfitting\n",
           f"Selected model: train macro-F1 {sel['train_macro_f1']:.3f} vs test macro-F1 {sel['test']['macro_f1']:.3f} "
           f"(gap {gap:+.3f}) - {verdict}. Absolute test macro-F1 is {sel['test']['macro_f1']:.3f}"
           + (", which is modest: the available contextual features carry limited signal for severity, so some "
              "underfitting relative to a perfect classifier is expected and is not fixable by tuning alone." if sel["test"]["macro_f1"] < 0.6 else ".")
           + f" Identical feature vectors: {meta['test_rows_identical_to_train_pct']:.1f}% of test rows have an exact "
             "feature match in the training set (inevitable with low-cardinality categorical features); this can make test scores slightly optimistic.\n"]

    ex = pick_examples(pipe, X_test, y_test)
    md += ["## 7. Real test-set examples\n",
           "One correctly and one incorrectly classified record per true class (where such rows exist). "
           "No identifiers or locations are included.\n", ex.to_markdown(), "",
           "## 8. Limitations\n",
           "- Features describe road, time and environment only; no vehicle speed, impact force or occupant data.",
           "- Single-country, single-period data; may not transfer to other regions (e.g. India).",
           "- Labels are police-recorded and are limited to what was known at the time of recording.",
           "- Not a certified safety system; see the disclaimer in the API and dashboard."]
    (C.REPORTS_DIR / "model_evaluation.md").write_text("\n".join(md), encoding="utf-8")
    meta["worked_example"] = write_worked_example(pipe, X_test, y_test, C.REPORTS_DIR / "worked_example.md")


def main() -> None:  # pragma: no cover - thin wrapper
    print("Run `python -m src.train`; it calls write_model_evaluation() with fresh results.")
    print(json.dumps({"reports_dir": str(C.REPORTS_DIR)}))


if __name__ == "__main__":
    main()
