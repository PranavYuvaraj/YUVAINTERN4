"""Load the serialised pipeline and make predictions (used by the API)."""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from src import config as C


class ModelNotAvailableError(RuntimeError):
    """Model file missing or unreadable."""


@dataclass
class ModelBundle:
    pipeline: object
    metadata: dict = field(default_factory=dict)


def load_model(model_path: Path | str = C.MODEL_PATH, metadata_path: Path | str = C.METADATA_PATH) -> ModelBundle:
    model_path, metadata_path = Path(model_path), Path(metadata_path)
    if not model_path.exists():
        raise ModelNotAvailableError(f"Model file not found: {model_path}. Run `python -m src.train` first.")
    try:
        pipeline = joblib.load(model_path)
    except Exception as exc:  # corrupt file, version mismatch, ...
        raise ModelNotAvailableError(f"Could not load model {model_path}: {exc}") from exc
    meta = {}
    if metadata_path.exists():
        try:
            meta = json.loads(metadata_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            meta = {}
    return ModelBundle(pipeline, meta)


def predict_one(bundle: ModelBundle, features: dict) -> dict:
    """features: dict with every name in config.RAW_FEATURES (None allowed -> imputed)."""
    row = pd.DataFrame([{k: features.get(k) for k in C.RAW_FEATURES}], dtype="float64")
    pipe = bundle.pipeline
    proba = pipe.predict_proba(row)[0]
    probs = {str(c): float(p) for c, p in zip(pipe.classes_, proba)}
    ordered = {c: round(probs.get(c, 0.0), 4) for c in C.CLASS_ORDER}
    label = str(pipe.classes_[int(np.argmax(proba))])
    return {"severity": label, "probabilities": ordered, "confidence": ordered[label]}
