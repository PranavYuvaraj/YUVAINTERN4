"""Fill docs templates with REAL results from a training run.

Requires: models/model_metadata.json, reports/metrics.json, reports/eda_findings.md,
reports/model_evaluation.md (created by `python -m src.eda` and `python -m src.train`).
Writes: docs/PROJECT_REPORT.md, docs/PRESENTATION.md, docs/REVIEWER_QA.md and the
results block of README.md. Usage: python -m src.build_docs
"""
from __future__ import annotations

import json
import re
import sys

from src import config as C

TPL = C.ROOT / "docs" / "templates"
SK = {"Logistic Regression": "lr", "Decision Tree": "dt", "Random Forest": "rf", "Baseline (most frequent)": "base"}


def _body(path, drop_title=True):
    t = path.read_text(encoding="utf-8")
    return re.sub(r"^# .*\n", "", t, count=1).replace("](figures/", "](../reports/figures/") if drop_title else t


def collect() -> dict:
    need = [C.METADATA_PATH, C.REPORTS_DIR / "metrics.json", C.REPORTS_DIR / "eda_findings.md",
            C.REPORTS_DIR / "model_evaluation.md"]
    missing = [str(p) for p in need if not p.exists()]
    if missing:
        sys.exit("Missing artifacts (run `python -m src.eda` and `python -m src.train` first): " + ", ".join(missing))
    meta = json.loads(C.METADATA_PATH.read_text(encoding="utf-8"))
    res = json.loads((C.REPORTS_DIR / "metrics.json").read_text())["results"]
    sel = meta["model_name"]; st = res[sel]["test"]; q = meta["data_quality"]
    v = {"dataset_file": meta["dataset_file"], "n_rows": f"{meta['n_rows']:,}", "n_train": f"{meta['n_train']:,}",
         "n_test": f"{meta['n_test']:,}", "trained_at": meta["trained_at"], "selected": sel,
         "best_params": json.dumps(meta["best_params"]), "sklearn": meta["versions"]["scikit-learn"],
         "python": meta["versions"]["python"], "cv_f1": f"{res[sel]['cv_macro_f1_mean']:.3f}",
         "acc": f"{st['accuracy']:.3f}", "macro_f1": f"{st['macro_f1']:.3f}", "macro_p": f"{st['macro_precision']:.3f}",
         "macro_r": f"{st['macro_recall']:.3f}", "auc": f"{st['roc_auc_ovr_macro']:.3f}" if st["roc_auc_ovr_macro"] else "n/a",
         "train_f1": f"{res[sel]['train_macro_f1']:.3f}", "gap": f"{res[sel]['train_macro_f1'] - st['macro_f1']:+.3f}",
         "high_recall": f"{st['per_class']['High']['recall']:.3f}", "high_prec": f"{st['per_class']['High']['precision']:.3f}",
         "low_recall": f"{st['per_class']['Low']['recall']:.3f}", "mod_recall": f"{st['per_class']['Moderate']['recall']:.3f}",
         "base_acc": f"{res['Baseline (most frequent)']['test']['accuracy']:.3f}",
         "base_f1": f"{res['Baseline (most frequent)']['test']['macro_f1']:.3f}",
         "identical_pct": f"{meta['test_rows_identical_to_train_pct']:.1f}", "dup_feature_rows": f"{q['duplicate_feature_rows']:,}",
         "reload_ok": str(all(meta["reload_verified"].values())), "n_features": len(C.RAW_FEATURES)}
    for c in C.CLASS_ORDER:
        v[f"cnt_{c}"] = f"{q['class_counts'][c]:,}"; v[f"pct_{c}"] = f"{q['class_percent'][c]:.2f}"
    for name, k in SK.items():
        v[f"{k}_f1"] = f"{res[name]['test']['macro_f1']:.3f}"; v[f"{k}_acc"] = f"{res[name]['test']['accuracy']:.3f}"
        v[f"{k}_hr"] = f"{res[name]['test']['per_class']['High']['recall']:.3f}"
        v[f"{k}_cv"] = "n/a" if res[name]["cv_macro_f1_mean"] is None else f"{res[name]['cv_macro_f1_mean']:.3f}"
    rows = ["| Model | CV macro-F1 | Accuracy | Macro-P | Macro-R | Macro-F1 | High recall | ROC-AUC |", "|---|---|---|---|---|---|---|---|"]
    for n, r in res.items():
        t = r["test"]; cv = "n/a" if r["cv_macro_f1_mean"] is None else f"{r['cv_macro_f1_mean']:.3f}"
        rows.append(f"| {n} | {cv} | {t['accuracy']:.3f} | {t['macro_precision']:.3f} | {t['macro_recall']:.3f} | "
                    f"{t['macro_f1']:.3f} | {t['per_class']['High']['recall']:.3f} | "
                    f"{(t['roc_auc_ovr_macro'] or float('nan')):.3f} |")
    v["comparison_table"] = "\n".join(rows)
    note = C.ROOT / "dataset" / "DATA_NOTE.txt"
    v["data_note"] = ("> **" + note.read_text(encoding="utf-8").strip() + "**\n\n") if note.exists() else ""
    v["eda_findings"] = _body(C.REPORTS_DIR / "eda_findings.md")
    v["model_evaluation"] = _body(C.REPORTS_DIR / "model_evaluation.md")
    we = C.REPORTS_DIR / "worked_example.md"
    v["worked_example"] = _body(we) if we.exists() else "(worked example not generated)"
    tr = C.REPORTS_DIR / "test_results.txt"
    v["test_results"] = tr.read_text(encoding="utf-8") if tr.exists() else "Run `pytest` and paste the summary here (reports/test_results.txt not found)."
    return v


def render(text: str, v: dict) -> str:
    def sub(m):
        k = m.group(1).strip()
        if k not in v:
            raise KeyError(f"Template placeholder {{{{{k}}}}} has no value")
        return str(v[k])
    return re.sub(r"\{\{(.*?)\}\}", sub, text)


def screenshot_gallery() -> str:
    shots = sorted((C.ROOT / "screenshots").glob("*.png"))
    if not shots:
        return ("_No screenshots yet. Run `python scripts/capture_screenshots.py` after starting the API and dashboard "
                "(see `screenshots/README.md`), then `python -m src.build_docs`._")
    return "\n\n".join(f"**{s.stem[3:].replace('_', ' ').title() if s.stem[:2].isdigit() else s.stem}**\n\n![{s.stem}](screenshots/{s.name})"
                        for s in shots)


def main():
    v = collect()
    for name in ("PROJECT_REPORT", "PRESENTATION", "REVIEWER_QA"):
        (C.ROOT / "docs" / f"{name}.md").write_text(render((TPL / f"{name}.md.tpl").read_text(encoding="utf-8"), v), encoding="utf-8")
        print("wrote docs/%s.md" % name)
    readme = C.ROOT / "README.md"
    block = render((TPL / "README_results.md.tpl").read_text(encoding="utf-8"), v)
    t = readme.read_text(encoding="utf-8")
    new = re.sub(r"<!-- RESULTS:START -->.*?<!-- RESULTS:END -->", lambda m: f"<!-- RESULTS:START -->\n{block}\n<!-- RESULTS:END -->", t, flags=re.S)
    new = re.sub(r"<!-- SCREENSHOTS:START -->.*?<!-- SCREENSHOTS:END -->",
                 lambda m: f"<!-- SCREENSHOTS:START -->\n{screenshot_gallery()}\n<!-- SCREENSHOTS:END -->", new, flags=re.S)
    readme.write_text(new, encoding="utf-8"); print("updated README results and screenshot blocks")


if __name__ == "__main__":
    main()
