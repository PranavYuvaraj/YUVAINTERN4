# reports/

Generated, not hand-written. After placing the dataset (see `../dataset/README.md`):

```
python -m src.eda      # eda_findings.md, eda_stats.json, figures/
python -m src.train    # model_evaluation.md, worked_example.md, metrics.json, figures/, models/*
```
