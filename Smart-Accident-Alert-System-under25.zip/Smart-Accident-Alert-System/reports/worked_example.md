# Worked example: one real test record through the pipeline

Row index in the test set: `21044` (identifiers, coordinates and police-force fields are not used and not shown).

## 1. Raw model inputs (codes as stored in the dataset)

|                         |   value |
|:------------------------|--------:|
| speed_limit             |      60 |
| number_of_vehicles      |       1 |
| hour                    |      23 |
| month                   |       4 |
| day_of_week             |       4 |
| road_type               |       6 |
| junction_detail         |       0 |
| first_road_class        |       5 |
| light_conditions        |       7 |
| weather_conditions      |       1 |
| road_surface_conditions |       2 |
| urban_or_rural_area     |       2 |

## 2. After `FeatureEngineer` (unknown codes -> NaN, vehicle cap, engineered flags)

|                         |   value |
|:------------------------|--------:|
| speed_limit             |      60 |
| number_of_vehicles      |       1 |
| hour                    |      23 |
| month                   |       4 |
| day_of_week             |       4 |
| road_type               |       6 |
| junction_detail         |       0 |
| first_road_class        |       5 |
| light_conditions        |       7 |
| weather_conditions      |       1 |
| road_surface_conditions |       2 |
| urban_or_rural_area     |       2 |
| is_weekend              |       0 |
| is_rush_hour            |       0 |
| is_night                |       1 |

## 3. After imputation, scaling and one-hot encoding

53 encoded features; the non-zero ones are:

| encoded_feature                  |     value |
|:---------------------------------|----------:|
| num__speed_limit                 |  1.39789  |
| num__number_of_vehicles          | -1.11631  |
| num__hour                        |  1.88917  |
| num__month                       | -0.723099 |
| cat__day_of_week_4.0             |  1        |
| cat__road_type_6.0               |  1        |
| cat__junction_detail_0.0         |  1        |
| cat__first_road_class_5.0        |  1        |
| cat__light_conditions_7.0        |  1        |
| cat__weather_conditions_1.0      |  1        |
| cat__road_surface_conditions_2.0 |  1        |
| cat__urban_or_rural_area_2.0     |  1        |
| cat__is_weekend_0.0              |  1        |
| cat__is_rush_hour_0.0            |  1        |
| cat__is_night_1.0                |  1        |

## 4. Model output

Class probabilities: `{'Low': 0.0203, 'Moderate': 0.2804, 'High': 0.6993}`

- **Predicted:** High   - **Actual:** High
