# EDA findings

_All values computed from the loaded dataset (100,000 rows)._

## 1. Dataset structure and quality

- Shape: **100,000 rows x 15 columns** (model inputs: 12 features + target).
- Duplicate `collision_index` values: 0. Rows with identical feature values (different collisions that look alike): 7,245 (7.2%); these are expected with categorical road/weather features and are kept.
- Rows dropped for unmapped severity label: 0.
- Unlisted category codes found: none.

| Feature | dtype | Missing/unknown | % |
|---|---|---|---|
| speed_limit | int64 | 0 | 0.00% |
| number_of_vehicles | int64 | 0 | 0.00% |
| hour | int32 | 0 | 0.00% |
| month | int32 | 0 | 0.00% |
| day_of_week | int64 | 0 | 0.00% |
| road_type | int64 | 513 | 0.51% |
| junction_detail | int64 | 484 | 0.48% |
| first_road_class | int64 | 0 | 0.00% |
| light_conditions | int64 | 0 | 0.00% |
| weather_conditions | int64 | 1,004 | 1.00% |
| road_surface_conditions | int64 | 980 | 0.98% |
| urban_or_rural_area | int64 | 0 | 0.00% |

![missing](figures/missing_values.png)

**What it shows / why it matters:** unknown codes (-1, 9, 99 ...) were converted to missing. The highest share is `weather_conditions` at 1.00%. Because missingness is small or moderate, median/most-frequent imputation (fitted on training data only) is used instead of dropping rows, which would shrink the rarest class further.

## 2. Target distribution

![target](figures/target_distribution.png)

| Class | Count | % |
|---|---|---|
| Low | 77,000 | 77.00% |
| Moderate | 21,500 | 21.50% |
| High | 1,500 | 1.50% |

**Observation:** the largest class is 51.3x the size of the smallest. A classifier that always predicts `Low` would reach 77.0% accuracy while detecting no High cases. **Impact on modelling:** stratified splits, class-weighted learning and macro-F1/recall (not accuracy) for model selection.

## 3. Numeric feature distributions and outliers

![num](figures/numeric_distributions.png)

| Feature | min | median | mean | p99 | max |
|---|---|---|---|---|---|
| speed_limit | 20 | 30 | 39.26 | 70 | 70 |
| number_of_vehicles | 1 | 2 | 1.88 | 4 | 6 |
| hour | 0 | 14 | 13.34 | 23 | 23 |
| month | 1 | 6 | 6.50 | 12 | 12 |

**Outliers:** number_of_vehicles has p99 = 4 and max = 6; the pipeline caps it at 10, affecting 0 rows (0.000%). If this share looks material, change `MAX_VEHICLES_CAP` in `src/config.py` and retrain.

## 4. Severity rate by feature

Overall: High = 1.50%, Moderate+High = 23.00%. Categories with n < 200 are not ranked.

### speed_limit

![speed_limit](figures/severity_by_speed_limit.png)

**Observed:** highest High-severity share is **70** at 8.69% (n=4,913); lowest is **20** at 0.01% (n=9,043); overall 1.50%. That is a 785.9x spread. **Why it matters:** a wide spread means the feature separates classes and is worth keeping; a narrow spread means weak signal. The model uses it as a one-hot / numeric input accordingly.

### light_conditions

![light_conditions](figures/severity_by_light_conditions.png)

**Observed:** highest High-severity share is **Darkness - no lighting** at 10.12% (n=5,680); lowest is **Daylight** at 0.75% (n=76,354); overall 1.50%. That is a 13.5x spread. **Why it matters:** a wide spread means the feature separates classes and is worth keeping; a narrow spread means weak signal. The model uses it as a one-hot / numeric input accordingly.

### road_type

![road_type](figures/severity_by_road_type.png)

**Observed:** highest High-severity share is **One way street** at 1.94% (n=1,912); lowest is **Slip road** at 1.36% (n=2,204); overall 1.50%. That is a 1.4x spread. **Why it matters:** a wide spread means the feature separates classes and is worth keeping; a narrow spread means weak signal. The model uses it as a one-hot / numeric input accordingly.

### urban_or_rural_area

![urban_or_rural_area](figures/severity_by_urban_or_rural_area.png)

**Observed:** highest High-severity share is **Rural** at 4.00% (n=36,033); lowest is **Urban** at 0.09% (n=63,967); overall 1.50%. That is a 42.6x spread. **Why it matters:** a wide spread means the feature separates classes and is worth keeping; a narrow spread means weak signal. The model uses it as a one-hot / numeric input accordingly.

### road_surface_conditions

![road_surface_conditions](figures/severity_by_road_surface_conditions.png)

**Observed:** highest High-severity share is **Frost or ice** at 2.72% (n=993); lowest is **Dry** at 1.47% (n=76,251); overall 1.50%. That is a 1.9x spread. **Why it matters:** a wide spread means the feature separates classes and is worth keeping; a narrow spread means weak signal. The model uses it as a one-hot / numeric input accordingly.

### weather_conditions

![weather_conditions](figures/severity_by_weather_conditions.png)

**Observed:** highest High-severity share is **Fog or mist** at 3.08% (n=975); lowest is **Other** at 1.32% (n=3,404); overall 1.50%. That is a 2.3x spread. **Why it matters:** a wide spread means the feature separates classes and is worth keeping; a narrow spread means weak signal. The model uses it as a one-hot / numeric input accordingly.

### junction_detail

![junction_detail](figures/severity_by_junction_detail.png)

**Observed:** highest High-severity share is **Not at junction or within 20 m** at 2.32% (n=42,271); lowest is **Mini-roundabout** at 0.51% (n=2,746); overall 1.50%. That is a 4.5x spread. **Why it matters:** a wide spread means the feature separates classes and is worth keeping; a narrow spread means weak signal. The model uses it as a one-hot / numeric input accordingly.

## 5. Time of day

![hour](figures/severity_by_hour.png)

**Observed:** High share peaks at hour 23:00 (6.21%, n=1,835) and is lowest at 6:00 (0.48%). Collision volume peaks at 17:00 (8,286 collisions), i.e. the busiest hour is not necessarily the most severe. **Influence:** motivates the engineered `is_night`, `is_rush_hour` and `is_weekend` flags.

## 6. Correlation

![corr](figures/correlation_heatmap.png)

**Observed (Spearman correlation with ordinal severity Low<Moderate<High):** speed_limit +0.478, is_night +0.162, number_of_vehicles -0.107, is_rush_hour -0.083. Absolute values near 0 mean no monotonic relationship; non-monotonic effects (e.g. hour) can still matter, which is why tree-based models are compared against the linear baseline.

## 7. Relationship: speed limit x urban/rural (High-severity %)

|   speed_limit |   Urban |   Rural |
|--------------:|--------:|--------:|
|            20 |    0.01 |  nan    |
|            30 |    0.06 |    0.39 |
|            40 |    0.09 |    0.97 |
|            50 |    0.51 |    1.96 |
|            60 |    0.58 |    4.57 |
|            70 |    3.9  |    9.01 |

**Why it matters:** if the High share differs by area type *within* the same speed limit, the two features carry partly independent information and an interaction-capable model (tree/forest) may help.
