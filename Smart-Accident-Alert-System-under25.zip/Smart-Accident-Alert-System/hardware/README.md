# Hardware Module Documentation

## Overview

The hardware module is the critical foundation of the Smart Accident Alert System. It detects vehicle crashes in real-time through airbag deployment sensors and transmits emergency data to the cloud backend.

---

## Components & Specifications

### 1. Microcontroller
- **Device**: ESP32 (or Arduino MKR GSM 1400)
- **Processor**: Dual-core Xtensa 32-bit LX6 @ 240 MHz
- **RAM**: 512 KB SRAM
- **Flash**: 16 MB (typical)
- **Features**: Wi-Fi, Bluetooth, CAN bus support
- **Power**: 3.3V, ~100 mA avg current

### 2. Airbag Sensor Interface
- **Type**: Airbag ECU signal tap
- **Voltage**: 5V logic signals
- **Signal**: High when airbag triggers
- **Connection**: Analog input pin (GPIO ADC)
- **Response Time**: <10ms

### 3. GPS Module
- **Device**: NEO-6M or u-blox MAX-M10S
- **Accuracy**: ±5 meters (±2.5m for MAX-M10S)
- **Cold Start**: <45 seconds
- **Hot Start**: <1 second
- **Update Rate**: 1-10 Hz
- **Interface**: UART (9600 baud)

### 4. Accelerometer
- **Device**: MPU-6050 (6-axis) or BMI160 (6-axis)
- **Range**: ±16G
- **Sensitivity**: 2048 LSB/G
- **Interface**: I2C
- **Function**: Measures impact force, validates severity

### 5. GSM/4G Module
- **Device**: SIM7600 (4G LTE) or SIM800L (GSM)
- **Bands**: LTE B1-B7, B20, GSM 850/900/1800/1900
- **Data Rate**: LTE 10 Mbps, GSM 85 kbps
- **Interface**: Serial UART
- **Power**: 1-2A peak current
- **Antenna**: External GSM antenna (required)

### 6. Power Management
- **Battery**: 24V vehicle auxiliary battery
- **Buck Converter**: 24V → 5V (2A continuous)
- **Backup Battery**: 3.7V Li-ion (5000mAh) with charging circuit
- **Fuse**: 5A inline fuse for main circuit
- **Status LED**: Battery health indicator

---

## Wiring Diagram

```
┌─────────────────────────────────────────────┐
│           Vehicle 24V Battery                │
└──────────────────┬──────────────────────────┘
                   │
          ┌────────▼─────────┐
          │  Buck Converter  │
          │  24V → 5V (2A)   │
          └────────┬─────────┘
                   │
      ┌────────────┼────────────┐
      ▼            ▼            ▼
   ┌──────┐   ┌──────┐    ┌─────────┐
   │ ESP  │   │Power │    │ Backup  │
   │  32  │   │ Dist │    │ Battery │
   └──┬───┘   └──────┘    └────┬────┘
      │                        │
      ├────────────────────────┘
      │
      ├─ GPIO 32 (ADC) ───────────────────── Airbag Sensor
      ├─ GPIO 16 (RX2) / GPIO 17 (TX2) ──── GPS Module
      ├─ GPIO 21 (SDA) / GPIO 22 (SCL) ──── Accelerometer
      ├─ GPIO 9 (RX) / GPIO 10 (TX) ─────── GSM Module
      │
      └─ Status LED (GPIO 2)
```

---

## Firmware Architecture

### Directory Structure
```
hardware/firmware/
├── src/
│   ├── main.cpp              # Entry point
│   ├── sensors/
│   │   ├── airbag.cpp        # Airbag detection
│   │   ├── gps.cpp           # GPS parsing
│   │   └── accelerometer.cpp # Impact measurement
│   ├── communication/
│   │   ├── gsm.cpp           # GSM/4G module
│   │   └── message.cpp       # Message formatting
│   ├── storage/
│   │   └── queue.cpp         # Offline message queue
│   └── config/
│       └── config.h          # Configuration constants
├── include/
│   ├── sensors.h
│   ├── communication.h
│   └── config.h
├── platformio.ini            # Build configuration
├── CMakeLists.txt
└── README.md
```

### Key Algorithm: Impact Detection

```cpp
// Pseudo-code for impact validation
void onAirbagSignal() {
    // 1. Confirm airbag trigger
    if (!isAirbagTriggered()) return;
    
    // 2. Read accelerometer (must detect high G-force)
    float gForce = readAccelerometer();
    if (gForce < 10.0) return;  // Minimum 10G for crash
    
    // 3. Calculate impact severity (1-10)
    int severity = calculateSeverity(gForce);
    
    // 4. Capture GPS location
    GPS_Coordinates location = getGPSLocation();
    
    // 5. Create alert message
    CrashAlert alert = {
        timestamp: millis(),
        latitude: location.lat,
        longitude: location.lng,
        severity: severity,
        gForce: gForce
    };
    
    // 6. Transmit immediately, queue if fails
    if (!transmitAlert(alert)) {
        queueAlert(alert);
    }
}
```

### State Machine

```
IDLE
  │
  ├─ Airbag Signal
  │  └─▶ READ_SENSORS (2-3 seconds)
  │      ├─ Read accelerometer
  │      ├─ Validate G-force
  │      └─ If invalid: return to IDLE
  │
  └─ Valid Crash Detected
     └─▶ CAPTURE_LOCATION (5-10 seconds)
         ├─ Get GPS coordinates
         ├─ Calculate severity
         └─▶ TRANSMIT (2-3 seconds)
             ├─ Format message
             ├─ Send via 4G/GSM
             ├─ If success: IDLE
             └─ If fail: QUEUE
                └─ Retry every 30s
                └─ Timeout after 24hrs
```

---

## Setup Instructions

### 1. Install Development Environment

**Option A: Arduino IDE**
```bash
# 1. Download Arduino IDE from https://www.arduino.cc/en/software
# 2. Install ESP32 board support
#    - File → Preferences
#    - Add to "Additional Boards Manager URLs":
#      https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
# 3. Tools → Board → esp32 → ESP32 Dev Module
```

**Option B: PlatformIO (Recommended)**
```bash
# Install VSCode PlatformIO Extension
# Or via pip:
pip install platformio

# Verify installation
platformio --version
```

### 2. Wire the Hardware

Follow the wiring diagram above. Ensure:
- All 5V connections properly insulated
- GSM antenna connected (critical for signal)
- Backup battery fully charged
- Airbag sensor properly tapped to vehicle ECU

### 3. Flash Firmware

**Using Arduino IDE:**
```bash
# 1. Open Arduino IDE
# 2. File → Open → hardware/firmware/src/main.cpp
# 3. Select Tools → Board → ESP32 Dev Module
# 4. Select Tools → Port → COM3 (or your device port)
# 5. Click Upload
```

**Using PlatformIO:**
```bash
cd hardware/firmware
platformio run -t upload
```

### 4. Configuration

Edit `hardware/firmware/src/config/config.h`:

```cpp
#define DEVICE_ID "VEHICLE_001"
#define API_BASE_URL "https://api.smartalert.com/v1"
#define API_KEY "your_device_api_key"
#define DEVICE_SECRET "your_device_secret"

// Sensor thresholds
#define MIN_G_FORCE_THRESHOLD 10.0
#define AIRBAG_TRIGGER_TIME 100  // milliseconds
#define GPS_TIMEOUT 30000  // 30 seconds

// Network settings
#define GSM_APN "airtelbroadband"
#define GSM_USER ""
#define GSM_PASS ""
```

### 5. Testing

**Serial Monitor Debug:**
```bash
# Open Serial Monitor (Arduino IDE: Tools → Serial Monitor)
# Set baud rate: 115200
# Watch output:

[10:30:45] System Starting...
[10:30:46] Sensors Initialized
[10:30:47] GPS Module Ready
[10:30:48] GSM Module Ready
[10:31:00] READY FOR CRASH DETECTION
```

**Simulating a Crash (Development):**
```cpp
// In main.cpp, uncomment for testing:
// simulateCrash();  // Triggers alert without real crash
```

---

## Power Consumption

| Component | Idle | Active | Peak |
|-----------|------|--------|------|
| ESP32 | 10 mA | 80 mA | 200 mA |
| GPS | 40 mA | 100 mA | 150 mA |
| Accelerometer | 2 mA | 3 mA | 5 mA |
| GSM Module | 0 mA | 500 mA | 1500 mA |
| **Total** | **52 mA** | **683 mA** | **1.9 A** |

**Backup Battery Life**: ~8 hours of continuous operation

---

## Troubleshooting

### GPS Not Getting Lock
- Ensure antenna is connected and external
- Wait 45 seconds for cold start
- Verify GPS module UART connections
- Check for RF interference

### GSM Connection Failing
- Verify SIM card is active
- Ensure GSM antenna is connected
- Check APN settings for your provider
- Test with AT commands via serial terminal

### Airbag Signal Not Detected
- Verify sensor wiring to GPIO 32
- Test voltage levels: should go from 0V to 5V
- Check that GPIO 32 is properly configured as analog input
- Verify vehicle ECU connection

### Message Transmission Timeout
- Check cellular signal strength
- Verify API endpoint is reachable
- Ensure API key is correct
- Check message format in serial output

---

## Advanced Features

### Offline Message Queue

If network is unavailable, messages are queued locally:
```cpp
// Message queue: Maximum 100 messages, 24 hour retention
MessageQueue queue;
queue.push(crashAlert);
queue.save();  // Persisted in SPIFFS
```

### Firmware Updates Over-the-Air (OTA)

```cpp
// Check for firmware updates every day
if (shouldCheckFirmwareUpdate()) {
    updateFirmwareOTA();
}
```

### Low Power Mode

```cpp
// When 24V power cuts (accident scenario)
enterBackupPowerMode();
// Reduces sampling rate
// Limits GPS updates
// Critical: Always transmit alert
```

---

## Compliance & Safety

- **FCC Certification**: Required for GSM/4G module
- **Vehicle ECU Integration**: Must not interfere with vehicle systems
- **Battery Safety**: Use certified Li-ion battery
- **EMI/EMC**: Proper shielding required for automotive environment

---

## Support & Resources

- **ESP32 Documentation**: https://docs.espressif.com/projects/esp32-rtos-sdk/
- **Arduino Reference**: https://www.arduino.cc/reference/
- **PlatformIO Docs**: https://docs.platformio.org/
- **GPS Module Manual**: Check NEO-6M or MAX-M10S datasheet

---

**Version**: 1.0  
**Last Updated**: 2025
