import numpy as np
import pandas as pd
import pytest

from src import config as C
from src.feature_engineering import FeatureEngineer
from src.preprocessing import DatasetError, find_unlisted_codes, load_dataset, split_data
from tests.conftest import make_synthetic_stats19


def test_missing_file_gives_actionable_error(tmp_path):
    with pytest.raises(DatasetError, match="dataset/README.md"):
        load_dataset(tmp_path / "nope.csv")


def test_missing_columns_reported(tmp_path):
    p = tmp_path / "bad.csv"
    make_synthetic_stats19(50).drop(columns=["speed_limit"]).to_csv(p, index=False)
    with pytest.raises(DatasetError, match="speed_limit"):
        load_dataset(p)


def test_load_maps_labels_and_derives_time(synthetic_csv):
    df = load_dataset(synthetic_csv)
    assert set(df[C.TARGET]) <= set(C.CLASS_ORDER)
    assert df["hour"].between(0, 23).all() and df["month"].between(1, 12).all()
    assert "number_of_casualties" not in df.columns  # leakage column is not carried forward


def test_older_style_headers_are_aliased(tmp_path):
    raw = make_synthetic_stats19(200).rename(columns={"collision_severity": "Accident_Severity",
                                                      "collision_index": "Accident_Index", "speed_limit": "Speed_limit"})
    p = tmp_path / "old.csv"; raw.to_csv(p, index=False)
    assert len(load_dataset(p)) == 200


def test_split_is_stratified(synthetic_csv):
    df = load_dataset(synthetic_csv)
    X_tr, X_te, y_tr, y_te = split_data(df)
    for c in C.CLASS_ORDER:
        assert abs((y_tr == c).mean() - (y_te == c).mean()) < 0.01
    assert len(X_tr) + len(X_te) == len(df) and not set(X_tr.index) & set(X_te.index)


def test_unknown_codes_become_nan_and_vehicles_capped():
    X = pd.DataFrame([{**dict.fromkeys(C.RAW_FEATURES, 1), "speed_limit": 99, "road_type": 9,
                       "number_of_vehicles": 40, "hour": 30}])
    out = FeatureEngineer().transform(X)
    assert np.isnan(out.loc[0, "speed_limit"]) and np.isnan(out.loc[0, "road_type"])
    assert np.isnan(out.loc[0, "hour"])
    assert out.loc[0, "number_of_vehicles"] == C.MAX_VEHICLES_CAP


def test_engineered_flags():
    base = dict.fromkeys(C.RAW_FEATURES, 1)
    out = FeatureEngineer().transform(pd.DataFrame([{**base, "hour": 8, "day_of_week": 1},
                                                    {**base, "hour": 23, "day_of_week": 3}]))
    assert out["is_rush_hour"].tolist() == [1.0, 0.0]
    assert out["is_night"].tolist() == [0.0, 1.0]
    assert out["is_weekend"].tolist() == [1.0, 0.0]


def test_missing_feature_column_raises():
    with pytest.raises(ValueError, match="Missing required"):
        FeatureEngineer().transform(pd.DataFrame({"speed_limit": [30]}))


def test_unlisted_code_detection(synthetic_csv):
    df = load_dataset(synthetic_csv); df.loc[0, "road_type"] = 55
    assert find_unlisted_codes(df)["road_type"] == [55]


def test_legacy_severity_column_name_is_aliased(tmp_path):
    raw = make_synthetic_stats19(200).rename(columns={"collision_severity": "legacy_collision_severity"})
    raw["enhanced_severity_collision"] = 99  # must not be used as the target
    p = tmp_path / "new_schema.csv"; raw.to_csv(p, index=False)
    assert len(load_dataset(p)) == 200


def test_existing_collision_severity_not_overwritten(tmp_path):
    raw = make_synthetic_stats19(200); raw["legacy_collision_severity"] = 3
    p = tmp_path / "both.csv"; raw.to_csv(p, index=False)
    df = load_dataset(p)
    assert df["severity_code"].nunique() > 1  # kept the real column, not the constant legacy one
