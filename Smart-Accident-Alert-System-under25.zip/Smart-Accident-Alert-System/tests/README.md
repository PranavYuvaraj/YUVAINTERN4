# tests/
`pytest` from the repository root. `conftest.py` builds a SYNTHETIC STATS19-style CSV and trains a small model into a temp folder, only to exercise code paths; it is never used for reported results.
Files: `test_preprocessing.py`, `test_model.py`, `test_api.py` (includes live-server frontend-client checks), `test_eda.py`.
