import socket
import threading
import time

import pytest
import uvicorn
from fastapi.testclient import TestClient

from frontend import api_client
from tests.conftest import VALID_PAYLOAD


@pytest.fixture()
def client(trained, monkeypatch):
    monkeypatch.setenv("MODEL_PATH", str(trained["model_path"]))
    monkeypatch.setenv("MODEL_METADATA_PATH", str(trained["meta_path"]))
    from api.main import app
    with TestClient(app) as c:
        yield c


@pytest.fixture()
def client_no_model(tmp_path, monkeypatch):
    monkeypatch.setenv("MODEL_PATH", str(tmp_path / "absent.joblib"))
    from api.main import app
    with TestClient(app) as c:
        yield c


def test_root_and_health(client):
    assert client.get("/").json()["docs"] == "/docs"
    h = client.get("/health").json()
    assert h == {"status": "ok", "model_loaded": True, "detail": None}


def test_predict_valid(client):
    r = client.post("/predict", json=VALID_PAYLOAD)
    assert r.status_code == 200
    b = r.json()
    assert b["severity"] in ("Low", "Moderate", "High") and abs(sum(b["probabilities"].values()) - 1) < 1e-2
    assert "number_of_vehicles" in b["imputed_fields"] and "disclaimer" in b


def test_predict_all_fields(client):
    r = client.post("/predict", json={**VALID_PAYLOAD, "number_of_vehicles": 3, "day_of_week": 2,
                                      "month": 5, "junction_detail": 3, "first_road_class": 3})
    assert r.status_code == 200 and r.json()["imputed_fields"] == []


@pytest.mark.parametrize("patch", [
    {"speed_limit": 55}, {"hour": 25}, {"hour": -1}, {"road_type": 99}, {"light_conditions": 2},
    {"urban_or_rural_area": 3}, {"number_of_vehicles": 0}, {"number_of_vehicles": 500},
    {"month": 13}, {"speed_limit": "fast"}, {"unknown_field": 1}])
def test_invalid_inputs_rejected(client, patch):
    assert client.post("/predict", json={**VALID_PAYLOAD, **patch}).status_code == 422


@pytest.mark.parametrize("missing", ["speed_limit", "hour", "light_conditions"])
def test_missing_required_rejected(client, missing):
    p = {k: v for k, v in VALID_PAYLOAD.items() if k != missing}
    assert client.post("/predict", json=p).status_code == 422


def test_bad_method_and_empty_body(client):
    assert client.get("/predict").status_code == 405
    assert client.post("/predict", content="not json").status_code == 422


def test_model_info(client):
    j = client.get("/model-info").json()
    assert j["classes"] == ["Low", "Moderate", "High"] and "speed_limit" in j["features"]
    assert j["test_metrics"]["accuracy"] >= 0


def test_model_unavailable(client_no_model):
    h = client_no_model.get("/health").json()
    assert h["status"] == "degraded" and h["model_loaded"] is False
    assert client_no_model.post("/predict", json=VALID_PAYLOAD).status_code == 503
    assert client_no_model.get("/model-info").status_code == 503


def test_cors_headers(client):
    r = client.options("/predict", headers={"Origin": "http://localhost:8501",
                                            "Access-Control-Request-Method": "POST"})
    assert r.headers.get("access-control-allow-origin") == "http://localhost:8501"


# ---- frontend client <-> real running server -------------------------------
@pytest.fixture()
def live_server(trained, monkeypatch):
    monkeypatch.setenv("MODEL_PATH", str(trained["model_path"]))
    monkeypatch.setenv("MODEL_METADATA_PATH", str(trained["meta_path"]))
    from api.main import app
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    server = uvicorn.Server(uvicorn.Config(app, host="127.0.0.1", port=port, log_level="error"))
    t = threading.Thread(target=server.run, daemon=True); t.start()
    for _ in range(100):
        if server.started: break
        time.sleep(0.1)
    yield f"http://127.0.0.1:{port}"
    server.should_exit = True; t.join(timeout=5)


def test_frontend_client_end_to_end(live_server):
    assert api_client.get_health(live_server)["model_loaded"] is True
    assert api_client.predict(VALID_PAYLOAD, live_server)["severity"] in ("Low", "Moderate", "High")
    assert "feature_options" in api_client.get_model_info(live_server)
    with pytest.raises(api_client.ApiError, match="Invalid input"):
        api_client.predict({**VALID_PAYLOAD, "speed_limit": 55}, live_server)


def test_frontend_client_api_unavailable():
    with pytest.raises(api_client.ApiError, match="Cannot reach the API"):
        api_client.get_health("http://127.0.0.1:9")
