import json

import joblib
import numpy as np
import pandas as pd
import pytest
from sklearn.utils.validation import check_is_fitted

from src import config as C
from src.predict import ModelNotAvailableError, load_model, predict_one
from tests.conftest import VALID_PAYLOAD


def _full(**kw):
    return {**dict.fromkeys(C.RAW_FEATURES), **VALID_PAYLOAD, **kw}


def test_model_file_saved_fitted_and_reloadable(trained):
    assert trained["model_path"].exists()
    loaded = joblib.load(trained["model_path"])
    check_is_fitted(loaded[-1])
    assert list(loaded.classes_) and set(loaded.classes_) == set(C.CLASS_ORDER)


def test_loaded_model_matches_original(trained, synthetic_csv):
    from src.preprocessing import load_dataset, split_data
    _, X_te, _, _ = split_data(load_dataset(synthetic_csv))
    loaded = joblib.load(trained["model_path"])
    assert (loaded.predict(X_te) == trained["pipe"].predict(X_te)).all()
    assert np.allclose(loaded.predict_proba(X_te), trained["pipe"].predict_proba(X_te))
    assert all(trained["meta"]["reload_verified"].values())


def test_three_models_compared_with_metrics(trained):
    r = trained["results"]
    assert {"Logistic Regression", "Decision Tree", "Random Forest"} <= set(r)
    for name in ("Logistic Regression", "Decision Tree", "Random Forest"):
        assert 0 <= r[name]["test"]["accuracy"] <= 1 and r[name]["test"]["roc_auc_ovr_macro"] is not None
    sel = trained["meta"]["model_name"]
    assert r[sel]["cv_macro_f1_mean"] == max(r[n]["cv_macro_f1_mean"] for n in r if n != "Baseline (most frequent)")


def test_predict_one_valid(trained):
    out = predict_one(load_model(trained["model_path"], trained["meta_path"]), _full())
    assert out["severity"] in C.CLASS_ORDER and abs(sum(out["probabilities"].values()) - 1) < 1e-2


def test_missing_and_unexpected_values_do_not_crash(trained):
    b = load_model(trained["model_path"], trained["meta_path"])
    assert predict_one(b, dict.fromkeys(C.RAW_FEATURES))["severity"] in C.CLASS_ORDER  # all missing
    assert predict_one(b, _full(road_type=88, junction_detail=77))["severity"] in C.CLASS_ORDER  # unseen category


def test_model_file_unavailable(tmp_path):
    with pytest.raises(ModelNotAvailableError):
        load_model(tmp_path / "missing.joblib")


def test_corrupt_model_file(tmp_path):
    p = tmp_path / "bad.joblib"; p.write_bytes(b"not a model")
    with pytest.raises(ModelNotAvailableError):
        load_model(p)


def test_reports_and_metadata_generated(trained):
    md = (trained["reports"] / "model_evaluation.md").read_text(encoding="utf-8")
    assert "Confusion matrix interpretation" in md and "Real test-set examples" in md
    assert (trained["reports"] / "worked_example.md").exists()
    assert json.loads(trained["meta_path"].read_text())["features"] == C.RAW_FEATURES
