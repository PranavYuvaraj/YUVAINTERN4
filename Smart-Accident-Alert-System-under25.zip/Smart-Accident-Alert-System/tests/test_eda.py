from src import config as C
from src.eda import run
from src.preprocessing import load_dataset


def test_eda_generates_findings_and_figures(synthetic_csv, tmp_path, monkeypatch):
    monkeypatch.setattr(C, "REPORTS_DIR", tmp_path)
    monkeypatch.setattr(C, "FIGURES_DIR", tmp_path / "figures")
    text = run(load_dataset(synthetic_csv))
    assert "Target distribution" in text and "Correlation" in text and "Outliers" in text
    for fig in ("target_distribution.png", "missing_values.png", "correlation_heatmap.png", "severity_by_hour.png"):
        assert (tmp_path / "figures" / fig).exists()
    assert (tmp_path / "eda_findings.md").exists()
