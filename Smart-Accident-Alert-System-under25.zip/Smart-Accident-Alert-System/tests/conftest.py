"""Shared fixtures.

The data below is SYNTHETIC and exists only to exercise the code paths (loading,
pipeline, API) in automated tests. It is never used for reported results.
"""
import numpy as np
import pandas as pd
import pytest

from src import config as C


def make_synthetic_stats19(n=4000, seed=0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    speed = rng.choice(C.VALID_SPEED_LIMITS, n, p=[.05, .55, .1, .05, .15, .10])
    light = rng.choice([1, 4, 5, 6, 7], n, p=[.7, .2, .02, .07, .01])
    rural = rng.choice([1, 2], n, p=[.65, .35])
    z = -3.2 + 0.03 * (speed - 30) + 0.5 * (light > 1) + 0.4 * (rural == 2) + rng.normal(0, .5, n)
    p_high, p_mod = 1 / (1 + np.exp(-z)) * 0.5, 1 / (1 + np.exp(-(z + 1.8)))
    u = rng.random(n)
    sev = np.where(u < p_high, 1, np.where(u < p_high + p_mod * 0.6, 2, 3))
    df = pd.DataFrame({
        "collision_index": [f"SYN{i:06d}" for i in range(n)],
        "collision_severity": sev,
        "number_of_vehicles": rng.choice([1, 2, 3, 4, 12], n, p=[.3, .55, .1, .04, .01]),
        "number_of_casualties": rng.integers(1, 5, n),  # must be ignored by the pipeline
        "date": [f"{rng.integers(1, 28):02d}/{rng.integers(1, 13):02d}/2022" for _ in range(n)],
        "day_of_week": rng.integers(1, 8, n),
        "time": [f"{rng.integers(0, 24):02d}:{rng.integers(0, 60):02d}" for _ in range(n)],
        "speed_limit": speed,
        "road_type": rng.choice([1, 3, 6, 7, 9], n, p=[.05, .1, .75, .05, .05]),
        "junction_detail": rng.choice([0, 1, 3, 6, 9, 99], n),
        "first_road_class": rng.choice([1, 3, 4, 5, 6], n),
        "light_conditions": light,
        "weather_conditions": rng.choice([1, 2, 7, 9, -1], n, p=[.7, .15, .05, .05, .05]),
        "road_surface_conditions": rng.choice([1, 2, 4, 9], n, p=[.6, .3, .05, .05]),
        "urban_or_rural_area": rural,
    })
    return df


@pytest.fixture(scope="session")
def synthetic_csv(tmp_path_factory):
    p = tmp_path_factory.mktemp("data") / "synthetic_stats19.csv"
    make_synthetic_stats19().to_csv(p, index=False)
    return p


@pytest.fixture(scope="session")
def trained(synthetic_csv, tmp_path_factory):
    """Run the real training function once on synthetic data, outputs to a temp dir."""
    from src import train as T
    out = tmp_path_factory.mktemp("model")
    mp, meta_p = out / "model.joblib", out / "meta.json"
    mp_reports = tmp_path_factory.mktemp("reports")
    C_dirs = (C.REPORTS_DIR, C.FIGURES_DIR)
    C.REPORTS_DIR, C.FIGURES_DIR = mp_reports, mp_reports / "figures"
    try:
        pipe, meta, results = T.train(synthetic_csv, tune_rows=3000, model_path=mp, metadata_path=meta_p,
                                      write_reports=True, verbose=False)
    finally:
        C.REPORTS_DIR, C.FIGURES_DIR = C_dirs
    return {"pipe": pipe, "meta": meta, "results": results, "model_path": mp, "meta_path": meta_p,
            "reports": mp_reports}


VALID_PAYLOAD = {"speed_limit": 30, "hour": 18, "road_type": 6, "light_conditions": 4,
                 "weather_conditions": 2, "road_surface_conditions": 2, "urban_or_rural_area": 1}
