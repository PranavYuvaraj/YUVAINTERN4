# legacy_design (archived, NOT part of the ML application)

Original pre-alpha Flask / PostgreSQL / Redis / Celery design files from v1.0.0, kept for reference.
They were never runnable (the referenced `app.py`, SQL, nginx and Firebase files do not exist) and are not used by the ML app.

Changes made for security: hard-coded passwords/keys/secrets replaced by `${VARIABLES}` or `CHANGE_ME`,
`DEBUG` off, CORS narrowed, DB/Redis ports bound to localhost.
**If the original values (`SecurePassword123`, `dev_api_key_12345`, `dev_jwt_secret_key_*`) were ever used on any real system, rotate them.**

The original architecture/API/deployment documents are in `../docs/legacy_design/`.
