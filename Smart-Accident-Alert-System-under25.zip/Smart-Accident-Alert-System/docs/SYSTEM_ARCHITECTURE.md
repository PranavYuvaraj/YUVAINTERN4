# System architecture (implemented ML application)

(The original pre-alpha design is kept in `docs/legacy_design/SYSTEM_ARCHITECTURE.md`.)

## Components
| Component | File | Responsibility |
|---|---|---|
| Config | `src/config.py` | Paths, label map, feature lists, code tables - single source of truth |
| Loader | `src/preprocessing.py` | Read STATS19 CSV, normalise headers, map labels, derive hour/month, quality checks, stratified split |
| Features | `src/feature_engineering.py` | Stateless cleaning + flags, inside the pipeline |
| Training | `src/train.py` | Grid search, comparison, selection, Joblib save + reload verification |
| Evaluation | `src/evaluate.py` | Metrics, figures, report generation |
| EDA | `src/eda.py` | Figures + data-driven findings |
| Inference | `src/predict.py` | Load model, predict one record |
| API | `api/main.py`, `api/schemas.py` | REST service, validation, CORS |
| Dashboard | `frontend/app.py`, `frontend/api_client.py` | UI that calls the API |

## Data flow at prediction time
Dashboard form -> JSON -> `POST /predict` -> Pydantic validation -> DataFrame of `RAW_FEATURES` -> Pipeline (clean, impute, encode, classify) -> label + probabilities + list of imputed fields -> dashboard.

## Design decisions
- Single saved Pipeline prevents train/serve skew.
- Features limited to what can be known at report time; post-outcome fields excluded (leakage).
- Optional inputs are imputed and reported back to the user, not silently invented.
- No database: the prototype stores nothing; session history lives in Streamlit session state only.
- No emergency integration; the disclaimer is returned by the API and shown in the UI.
