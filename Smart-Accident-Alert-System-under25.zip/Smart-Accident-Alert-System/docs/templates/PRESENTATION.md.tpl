# Internship Presentation - Smart Accident Alert System (10 slides)

{{data_note}}
_Numbers are filled from the real training run ({{trained_at}})._

## Slide 1 - Title and introduction
Smart Accident Alert System with ML-based Accident Severity Prediction. Yuva Intern - Week 4: AI Project Deployment & Capstone. Presenter: Pranav Y. Educational prototype.

## Slide 2 - Problem statement
- Emergency responders and planners need a quick sense of how serious a collision may be.
- The original project (v1.0.0 pre-alpha) only had design documents; ML severity prediction was a listed future enhancement.
- Goal: turn it into a working, tested end-to-end ML application.

## Slide 3 - Objectives
Train and compare 3 classifiers - serialise with Joblib - serve with FastAPI - Streamlit dashboard - pytest tests - deployment-ready config - honest documentation.

## Slide 4 - Existing vs proposed system
| Existing (documented, not built) | Proposed (implemented) |
|---|---|
| Flask/Postgres/hardware design | FastAPI + Streamlit + Joblib model |
| Severity 1-10 from sensors (concept) | Low / Moderate / High from road & weather context |
| No code, no data, no tests | Pipeline, API, dashboard, tests |

## Slide 5 - Dataset and preprocessing
UK DfT STATS19 collisions ({{dataset_file}}): {{n_rows}} records. Slight/Serious/Fatal renamed to Low/Moderate/High. Classes: Low {{cnt_Low}} ({{pct_Low}}%), Moderate {{cnt_Moderate}} ({{pct_Moderate}}%), High {{cnt_High}} ({{pct_High}}%). Unknown codes -> missing -> imputed; vehicles capped; leakage columns excluded; stratified {{n_train}}/{{n_test}} split.

## Slide 6 - EDA findings
Strongest findings (see `reports/eda_findings.md` for graphs and exact figures): class imbalance (High = {{pct_High}}%), severity share by speed limit, light conditions and hour of day. Imbalance drives the choice of macro-F1 and class weighting.

## Slide 7 - Algorithms and training
Logistic Regression, Decision Tree, Random Forest; one sklearn Pipeline (feature engineering - imputation/scaling/one-hot - classifier); grid search with 3-fold stratified CV on macro-F1. Selected: **{{selected}}** {{best_params}}.

## Slide 8 - Comparison and evaluation
{{comparison_table}}

Selected model: accuracy {{acc}}, macro-F1 {{macro_f1}}, High recall {{high_recall}}. Train-test macro-F1 gap {{gap}}.

## Slide 9 - FastAPI, Joblib, deployment
Joblib file `models/accident_severity_model.joblib` (reload check: {{reload_ok}}). Endpoints `/`, `/health`, `/predict`, `/model-info`; Swagger at `/docs`. Render config provided (`render.yaml`) - **not deployed unless you do so**; steps in `docs/DEPLOYMENT.md`.

## Slide 10 - Conclusion and future work
Working, tested prototype with honest limits: context-only features, UK data, rare-class difficulty, no dispatch. Future: sensor features, local (India) data, calibration, SHAP explanations, monitoring, human-in-the-loop workflow.
