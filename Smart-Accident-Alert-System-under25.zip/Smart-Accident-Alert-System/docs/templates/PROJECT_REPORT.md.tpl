# Smart Accident Alert System with Machine Learning-Based Accident Severity Prediction

{{data_note}}
**Yuva Intern - Week 4: AI Project Deployment & Capstone** | Author: Pranav Y | Generated {{trained_at}}

> All numerical results in this report are produced by `python -m src.eda` and `python -m src.train` and inserted by `python -m src.build_docs`. Nothing is typed by hand.

## Abstract
This project converts a documentation-only accident alert design into a working machine-learning application. Using the UK DfT STATS19 collision records ({{n_rows}} rows), three classifiers (Logistic Regression, Decision Tree, Random Forest) were trained and compared to predict collision severity as Low, Moderate or High from road, weather, light and time conditions. **{{selected}}** was selected by cross-validated macro-F1 ({{cv_f1}}) and reached test accuracy {{acc}}, macro-F1 {{macro_f1}} and recall {{high_recall}} on the rare High class. The model is serialised with Joblib, served by FastAPI and used by a Streamlit dashboard. It is an educational prototype and never triggers emergency dispatch.

## 1. Introduction
Road collisions vary greatly in severity, and rapid severity estimation can help prioritise attention. The Smart Accident Alert System was designed (v1.0.0 pre-alpha) around vehicle sensors, GPS and ambulance matching; the README listed ML severity prediction as a future enhancement.

## 2. Problem statement
Given information available when a collision is reported (speed limit, road type, light, weather, surface, area type, time), predict the recorded severity class.

## 3. Objectives
1. Obtain and document a genuine dataset. 2. Preprocess and analyse it. 3. Train and compare three classifiers. 4. Serialise the full pipeline. 5. Provide a validated REST API. 6. Provide a dashboard. 7. Test and document honestly.

## 4. Background and references
Severity labels follow the DfT STATS19 definitions (Fatal, Serious, Slight). Methods used are standard: Random Forests (Breiman, 2001) and scikit-learn (Pedregosa et al., 2011). No wider literature survey is claimed; see References.

## 5. Existing system
Documented design only: Flask/PostgreSQL/Redis backend, ESP32 sensor concept, severity 1-10 from accelerometer data. The ZIP contained no source code, data, tests or trained model, and the status document overstated progress; these were corrected.

## 6. Proposed system
```
STATS19 CSV -> src/train.py -> models/accident_severity_model.joblib -> FastAPI (api/main.py) <- Streamlit (frontend/app.py)
```
A single scikit-learn Pipeline (FeatureEngineer -> ColumnTransformer -> classifier) is trained once and loaded unchanged by the API, so training and serving use identical preprocessing.

## 7. Dataset description
Source: UK Department for Transport Road Safety Data (STATS19), collision table, file `{{dataset_file}}`, Open Government Licence v3.0 (verify on the source page). Label mapping (rename, nothing merged): 1 Fatal -> High, 2 Serious -> Moderate, 3 Slight -> Low. Class counts: Low {{cnt_Low}} ({{pct_Low}}%), Moderate {{cnt_Moderate}} ({{pct_Moderate}}%), High {{cnt_High}} ({{pct_High}}%). Why this dataset: official, traceable, three-level severity matching the project classes, and inputs the application can supply. Rejected: US Accidents (severity measures traffic delay, not injury; very large). Excluded as leakage: number of casualties, police attendance.

## 8. Methodology
Stratified 80/20 split (random seed 42; {{n_train}} train / {{n_test}} test rows); all fitting (imputation, scaling, encoding, tuning) on training data only; grid search with 3-fold stratified CV scoring macro-F1; final model chosen on CV score, evaluated once on the test set; majority-class baseline for context.

## 9. Architecture
FastAPI endpoints: `GET /`, `GET /health`, `POST /predict`, `GET /model-info` (Pydantic validation, CORS from environment, 503 when the model is unavailable). Streamlit calls only the API. See `docs/SYSTEM_ARCHITECTURE.md`.

## 10. Preprocessing
Unknown codes (-1, 9, 99, ...) -> missing; median/most-frequent imputation; standard scaling of numeric features; one-hot encoding (unknown categories ignored at inference); `number_of_vehicles` capped at `MAX_VEHICLES_CAP` (see `src/config.py`); engineered flags `is_weekend`, `is_rush_hour`, `is_night`. Rows with identical feature values: {{dup_feature_rows}}.

## 11. Exploratory data analysis (actual findings)
{{eda_findings}}

## 12. Model development
Candidates and tuned hyper-parameters: Logistic Regression (C), Decision Tree (max depth, min leaf), Random Forest (trees, depth, min leaf), all class-weighted. Selected: **{{selected}}**, parameters {{best_params}}.

## 13-14. Model evaluation, results and discussion
{{model_evaluation}}

### Worked example
{{worked_example}}

## 15. API development
Pydantic schemas reject unknown fields, out-of-range numbers and unlisted category codes (HTTP 422). Required fields: speed limit, hour, road type, light, weather, surface, area type; others are optional and imputed (listed in the response). Example: `curl -X POST http://127.0.0.1:8000/predict -H "Content-Type: application/json" -d '{"speed_limit":30,"hour":18,"road_type":6,"light_conditions":4,"weather_conditions":2,"road_surface_conditions":2,"urban_or_rural_area":1}'`.

## 16. Deployment
Deployment-ready (Dockerfile, `render.yaml`, `.env.example`, start commands). **The application has not been deployed by this project package**; follow `docs/DEPLOYMENT.md` and record the live URLs yourself once verified.

## 17. Testing
pytest suite covering preprocessing, feature transformation, model save/load equality, predictions, API health, validation, invalid input, model-unavailable, API-unavailable and frontend-client/API integration. The fixtures use synthetic data only to verify code behaviour, not model quality.

```
{{test_results}}
```

## 18. Limitations
Context-only features (no impact force or vehicle speed); UK data; police-recorded labels; strong class imbalance (High recall {{high_recall}}, precision {{high_prec}}); {{identical_pct}}% of test rows have an exact feature match in training, so scores may be slightly optimistic; no calibration study; not a certified system.

## 19. Conclusion
A reproducible pipeline, tested API and dashboard were delivered. {{selected}} improved on the majority baseline (macro-F1 {{macro_f1}} vs {{base_f1}}), but the rare High class remains hard to detect from context alone, so outputs must support, never replace, human judgement.

## 20. Future scope
Sensor features (impact, airbag), India-specific data, probability calibration, SHAP explanations, monitoring and drift checks, authentication, human-verified alert workflow.

## References
- UK Department for Transport. *Road Safety Data* (STATS19), data.gov.uk. Open Government Licence v3.0.
- Breiman, L. (2001). Random Forests. *Machine Learning*, 45(1), 5-32.
- Pedregosa, F. et al. (2011). Scikit-learn: Machine Learning in Python. *JMLR*, 12, 2825-2830.
- FastAPI, Pydantic, Streamlit and Joblib official documentation.
