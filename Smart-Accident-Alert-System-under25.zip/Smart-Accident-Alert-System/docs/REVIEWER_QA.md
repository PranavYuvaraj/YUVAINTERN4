# Reviewer questions and answers
_Project-specific numbers come from the real run on 2026-11-26 05:35 UTC._

**1. Why this dataset?** UK DfT STATS19 is official, documented, open-licensed, has a three-level severity label (Fatal/Serious/Slight) and inputs the app can supply (road, weather, light, time). US Accidents was rejected because its severity measures traffic delay, not injury.

**2. How did you map labels?** One-to-one rename: Slight->Low, Serious->Moderate, Fatal->High. Nothing was merged, so the classes keep the police definition.

**3. What is the class distribution and why does it matter?** Low 77.00%, Moderate 21.50%, High 1.50%. A majority-class model gets accuracy 0.770 but macro-F1 0.290, so accuracy alone would hide failure on the rare class.

**4. How did you handle missing values?** Codes such as -1, 9 and 99 mean "unknown"; they become NaN and are imputed (median for numbers, most-frequent for categories) using statistics learned from the training set only.

**5. How did you prevent data leakage?** (a) Split before fitting anything; all transformers live inside the Pipeline. (b) Post-outcome columns (number of casualties, police attendance) are excluded. (c) Model selection used cross-validation on training data, not the test set.

**6. Why was `number_of_casualties` excluded?** It is known only after the collision and is strongly tied to severity; the live API could never supply it, and including it would give unrealistically high scores.

**7. What feature engineering did you do?** `is_weekend`, `is_rush_hour`, `is_night` from day and hour, one-hot encoding of coded categories, and a cap on `number_of_vehicles` to limit outliers.

**8. How are outliers handled?** The vehicle count is capped at `MAX_VEHICLES_CAP`; the EDA report states how many rows were affected. Tree models are also robust to outliers.

**9. Why classification rather than regression?** The target is three ordered categories, not a continuous quantity.

**10. How does Logistic Regression work here?** It learns a linear score per class on the one-hot/scaled features and converts scores to probabilities with softmax. Result: macro-F1 0.503 (High recall 0.707).

**11. How does a Decision Tree work, and how did you limit overfitting?** It splits features to make groups purer; depth and minimum leaf size were tuned by cross-validation. Result: macro-F1 0.499 (High recall 0.583).

**12. Why use Random Forest?** It averages many de-correlated trees, lowering variance and capturing interactions. Result: macro-F1 0.557 (High recall 0.453).

**13. Which model was selected and why?** Random Forest, chosen for the highest cross-validated macro-F1 (0.548); test accuracy 0.758, macro-F1 0.557. The test set was not used for the choice.

**14. Is the selected model overfitting?** Train macro-F1 0.651 vs test 0.557 (gap +0.095); the evaluation report interprets this gap. Also, 11.0% of test rows have an identical feature vector in training, which can make test scores slightly optimistic.

**15. What does cross-validation add?** It estimates performance on several train/validation folds (3-fold stratified here), reducing dependence on one lucky split and allowing tuning without touching the test set.

**16. Explain the confusion matrix and its errors.** Rows are actual classes, columns predicted. A false negative for High (a serious case predicted lower) is the most costly; the report counts them and gives High recall 0.453 and precision 0.191.

**17. Precision vs recall vs F1?** Precision = correct among predicted positives; recall = found among actual positives; F1 = their harmonic mean. Macro averages treat all classes equally, which suits imbalance.

**18. What is ROC-AUC and what did you get?** The probability that a random positive ranks above a random negative; computed one-vs-rest and macro-averaged: 0.864. It measures ranking quality independent of threshold.

**19. What is Joblib and why use it?** An efficient serialiser for scikit-learn objects (large numpy arrays). The whole fitted pipeline is saved, so the API cannot apply different preprocessing. Save/reload equality check passed: True.

**20. What are the risks of pickle/Joblib files?** They can execute code on load, so only load files you created; they are tied to scikit-learn versions (this model: 1.9.1); pin versions when deploying.

**21. Why FastAPI?** Automatic Swagger docs, Pydantic validation, type hints, speed, simple testing with TestClient.

**22. What does Pydantic do here?** It rejects unknown fields, wrong types, out-of-range values and category codes not in the training vocabulary, returning HTTP 422 before the model is called.

**23. How are frontend and backend connected?** Streamlit sends HTTP JSON to `/predict` via `frontend/api_client.py`; nothing is predicted locally. Integration is tested against a live uvicorn server.

**24. How is the system deployed?** Config for Render (`render.yaml`) and Docker is provided; it has **not** been deployed by this package. CORS and URLs are environment variables.

**25. What are the main limitations?** Context-only features, UK data, police labels, rare High class (recall 0.453), no calibration, not certified; it must never auto-trigger dispatch.

**26. How does this relate to the original project?** The original was a pre-alpha design with no code. This delivers the previously "future" ML severity component; hardware, notifications and ambulance matching remain unimplemented.

**27. How would you improve it?** Add sensor features, local data, calibration, threshold tuning for High recall, SHAP explanations, drift monitoring and authentication.

**28. Which security issues did you find?** Hard-coded dev credentials, wildcard CORS and debug mode in the original config. They were replaced with placeholders/environment variables and archived under `legacy_design/`; credentials that were ever used should be rotated.
