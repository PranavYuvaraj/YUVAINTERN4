# API documentation (FastAPI)
Start: `uvicorn api.main:app --port 8000`. Interactive docs: `/docs`; OpenAPI JSON: `/openapi.json`.

## GET /
Service name, version, endpoint list, disclaimer.

## GET /health
`{"status":"ok","model_loaded":true,"detail":null}`; status `degraded` and the load error when the model file is missing/corrupt.

## POST /predict
Required: `speed_limit` (20,30,40,50,60,70), `hour` (0-23), `road_type`, `light_conditions`, `weather_conditions`, `road_surface_conditions`, `urban_or_rural_area` (codes listed in `/model-info` -> `feature_options`).
Optional (imputed if omitted): `number_of_vehicles` (1-50), `day_of_week` (1=Sunday), `month` (1-12), `junction_detail`, `first_road_class`.

Response: `severity`, `confidence`, `probabilities` {Low, Moderate, High}, `imputed_fields`, `model_name`, `disclaimer`.

Errors: `422` invalid/missing/unknown fields or codes; `503` model not loaded; `500` generic prediction failure (details only in server logs).

## GET /model-info
Model name, classes, features, training metadata, test metrics, comparison of all models, and `feature_options` (code -> label).

## Configuration
`CORS_ORIGINS` (comma-separated), `MODEL_PATH`, `MODEL_METADATA_PATH`. No authentication is implemented; add it before any public production use.
