# API Documentation

## Base URL
```
Production: https://api.smartalert.com/v1
Development: http://localhost:5000/v1
```

## Authentication

All requests require authentication via API Key (for devices) or OAuth 2.0 (for mobile apps).

### Device Authentication
```bash
curl -H "X-API-Key: your_device_key" https://api.smartalert.com/v1/crash/report
```

### Mobile App Authentication
```bash
# Get token
POST /auth/login
Content-Type: application/json

{
  "email": "driver@example.com",
  "password": "password"
}

# Use token in header
Authorization: Bearer <jwt_token>
```

---

## Endpoints

### 1. Crash Reporting

#### Report Crash
```
POST /crash/report
Content-Type: application/json
X-API-Key: device_key

{
  "device_id": "VEHICLE_001",
  "latitude": 13.0827,
  "longitude": 80.2707,
  "severity": 8,
  "timestamp": "2025-01-15T10:30:45Z",
  "vehicle_info": {
    "make": "Toyota",
    "model": "Innova",
    "license_plate": "TN01AB1234"
  }
}

Response: 201 Created
{
  "crash_id": "crash_550e8400e29b",
  "status": "detected",
  "alert_status": "notifying",
  "message": "Crash registered successfully"
}
```

#### Get Crash Details
```
GET /crash/{crash_id}
Authorization: Bearer token

Response: 200 OK
{
  "crash_id": "crash_550e8400e29b",
  "device_id": "VEHICLE_001",
  "location": {
    "latitude": 13.0827,
    "longitude": 80.2707,
    "address": "Chennai, Tamil Nadu"
  },
  "severity": 8,
  "timestamp": "2025-01-15T10:30:45Z",
  "status": "resolved",
  "assigned_ambulance": {
    "ambulance_id": "AMB_001",
    "driver_name": "John Doe",
    "eta": 5,
    "distance": 2.3
  }
}
```

#### List Recent Crashes
```
GET /crash/list?limit=20&offset=0
Authorization: Bearer token

Response: 200 OK
{
  "total": 245,
  "crashes": [
    {
      "crash_id": "crash_550e8400e29b",
      "location": {
        "latitude": 13.0827,
        "longitude": 80.2707
      },
      "severity": 8,
      "timestamp": "2025-01-15T10:30:45Z",
      "status": "resolved"
    }
  ]
}
```

---

### 2. Ambulance Management

#### Get Available Ambulances
```
GET /ambulance/available?latitude=13.0827&longitude=80.2707&radius=5
X-API-Key: server_key

Response: 200 OK
{
  "nearby_ambulances": [
    {
      "ambulance_id": "AMB_001",
      "driver_id": "DRIVER_001",
      "driver_name": "John Doe",
      "current_location": {
        "latitude": 13.0850,
        "longitude": 80.2730
      },
      "distance": 0.5,
      "eta": 2,
      "availability": "available",
      "capacity": 2,
      "rating": 4.8
    },
    {
      "ambulance_id": "AMB_002",
      "driver_id": "DRIVER_002",
      "driver_name": "Jane Smith",
      "current_location": {
        "latitude": 13.0800,
        "longitude": 80.2700
      },
      "distance": 1.2,
      "eta": 4,
      "availability": "available",
      "capacity": 2,
      "rating": 4.9
    }
  ]
}
```

#### Assign Ambulance to Crash
```
POST /ambulance/assign
Content-Type: application/json
X-API-Key: server_key

{
  "crash_id": "crash_550e8400e29b",
  "ambulance_id": "AMB_001",
  "priority": "high"
}

Response: 201 Created
{
  "assignment_id": "assign_660f8401f30c",
  "crash_id": "crash_550e8400e29b",
  "ambulance_id": "AMB_001",
  "status": "notified",
  "assigned_at": "2025-01-15T10:30:50Z"
}
```

#### Update Ambulance Status
```
PUT /ambulance/{ambulance_id}/status
Content-Type: application/json
Authorization: Bearer driver_token

{
  "status": "en_route",
  "current_location": {
    "latitude": 13.0850,
    "longitude": 80.2730
  }
}

Response: 200 OK
{
  "ambulance_id": "AMB_001",
  "status": "en_route",
  "updated_at": "2025-01-15T10:31:05Z"
}
```

#### Set Ambulance Availability
```
PUT /ambulance/{ambulance_id}/availability
Content-Type: application/json
Authorization: Bearer driver_token

{
  "available": true,
  "current_location": {
    "latitude": 13.0850,
    "longitude": 80.2730
  }
}

Response: 200 OK
{
  "ambulance_id": "AMB_001",
  "availability": true,
  "updated_at": "2025-01-15T10:31:10Z"
}
```

---

### 3. Alert & Notification Management

#### Send Alert
```
POST /notify/send
Content-Type: application/json
X-API-Key: server_key

{
  "crash_id": "crash_550e8400e29b",
  "driver_id": "DRIVER_001",
  "notification_type": "crash_alert",
  "data": {
    "crash_id": "crash_550e8400e29b",
    "location": {
      "latitude": 13.0827,
      "longitude": 80.2707
    },
    "severity": 8,
    "distance": 0.5,
    "eta": 2
  }
}

Response: 200 OK
{
  "notification_id": "notif_770g8502g41d",
  "status": "sent",
  "sent_at": "2025-01-15T10:30:52Z"
}
```

#### Driver Accept Alert
```
POST /alert/{assignment_id}/accept
Content-Type: application/json
Authorization: Bearer driver_token

{
  "latitude": 13.0850,
  "longitude": 80.2730
}

Response: 200 OK
{
  "assignment_id": "assign_660f8401f30c",
  "status": "accepted",
  "accepted_at": "2025-01-15T10:31:00Z",
  "navigation_url": "https://maps.google.com/?destination=13.0827,80.2707"
}
```

#### Driver Decline Alert
```
POST /alert/{assignment_id}/decline
Content-Type: application/json
Authorization: Bearer driver_token

{
  "reason": "Too far away"
}

Response: 200 OK
{
  "assignment_id": "assign_660f8401f30c",
  "status": "declined",
  "declined_at": "2025-01-15T10:31:05Z"
}
```

#### Get Notification History
```
GET /notify/history?limit=50
Authorization: Bearer token

Response: 200 OK
{
  "total": 127,
  "notifications": [
    {
      "notification_id": "notif_770g8502g41d",
      "type": "crash_alert",
      "crash_id": "crash_550e8400e29b",
      "status": "delivered",
      "sent_at": "2025-01-15T10:30:52Z",
      "delivered_at": "2025-01-15T10:30:53Z"
    }
  ]
}
```

---

### 4. Driver Management

#### Driver Registration
```
POST /driver/register
Content-Type: application/json

{
  "email": "driver@example.com",
  "password": "securepassword",
  "name": "John Doe",
  "phone": "+919876543210",
  "license_number": "DL01234567890",
  "ambulance_id": "AMB_001"
}

Response: 201 Created
{
  "driver_id": "DRIVER_001",
  "email": "driver@example.com",
  "name": "John Doe",
  "status": "active",
  "created_at": "2025-01-15T10:30:45Z"
}
```

#### Get Driver Profile
```
GET /driver/profile
Authorization: Bearer driver_token

Response: 200 OK
{
  "driver_id": "DRIVER_001",
  "email": "driver@example.com",
  "name": "John Doe",
  "phone": "+919876543210",
  "ambulance_id": "AMB_001",
  "availability": true,
  "rating": 4.8,
  "total_responses": 245,
  "average_response_time": 3.5,
  "current_location": {
    "latitude": 13.0850,
    "longitude": 80.2730
  }
}
```

#### Update Driver Profile
```
PUT /driver/profile
Content-Type: application/json
Authorization: Bearer driver_token

{
  "phone": "+919876543210",
  "current_location": {
    "latitude": 13.0850,
    "longitude": 80.2730
  }
}

Response: 200 OK
{
  "driver_id": "DRIVER_001",
  "updated_at": "2025-01-15T10:31:15Z"
}
```

---

### 5. Analytics & Reporting

#### Get Dashboard Stats
```
GET /analytics/dashboard?from=2025-01-01&to=2025-01-31
Authorization: Bearer admin_token

Response: 200 OK
{
  "period": {
    "from": "2025-01-01",
    "to": "2025-01-31"
  },
  "total_crashes": 342,
  "total_ambulances": 45,
  "avg_response_time": 3.2,
  "lives_saved": 18,
  "alert_success_rate": 94.2,
  "peak_hour": "18:00-19:00"
}
```

#### Get Crash Analytics
```
GET /analytics/crashes?from=2025-01-01&to=2025-01-31&group_by=hour
Authorization: Bearer admin_token

Response: 200 OK
{
  "data": [
    {
      "timestamp": "2025-01-15T10:00:00Z",
      "count": 12,
      "avg_severity": 6.5
    }
  ],
  "total": 342
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "invalid_request",
  "message": "Invalid latitude value",
  "code": "INVALID_LATITUDE"
}
```

### 401 Unauthorized
```json
{
  "error": "unauthorized",
  "message": "Invalid or expired API key",
  "code": "INVALID_API_KEY"
}
```

### 404 Not Found
```json
{
  "error": "not_found",
  "message": "Crash with ID 'crash_xyz' not found",
  "code": "CRASH_NOT_FOUND"
}
```

### 429 Too Many Requests
```json
{
  "error": "rate_limited",
  "message": "Rate limit exceeded. Try again in 60 seconds",
  "code": "RATE_LIMIT_EXCEEDED"
}
```

### 500 Internal Server Error
```json
{
  "error": "server_error",
  "message": "An unexpected error occurred",
  "code": "INTERNAL_SERVER_ERROR"
}
```

---

## Rate Limits

| Endpoint | Limit | Window |
|----------|-------|--------|
| `/crash/report` | 1000 | 1 minute |
| `/ambulance/available` | 5000 | 1 minute |
| `/notify/send` | 10000 | 1 minute |
| Other endpoints | 1000 | 1 minute |

---

## WebSocket Events

### Real-Time Crash Updates
```
ws://api.smartalert.com/v1/ws/crash/{crash_id}

Events:
- "crash_detected" - Initial crash detection
- "ambulance_assigned" - Ambulance dispatched
- "driver_accepted" - Driver accepted alert
- "en_route" - Ambulance en route
- "arrived" - Ambulance arrived at scene
- "completed" - Incident resolved
```

### Real-Time Location Updates
```
ws://api.smartalert.com/v1/ws/ambulance/{ambulance_id}

Events:
- "location_updated" - Current location
- "status_changed" - Status change
- "assignment_changed" - New assignment
```

---

**Version**: 1.0  
**Last Updated**: 2025
