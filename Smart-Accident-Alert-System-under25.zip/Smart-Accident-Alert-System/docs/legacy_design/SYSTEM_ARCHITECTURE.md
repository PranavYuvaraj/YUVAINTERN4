# System Architecture

## High-Level Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    SMART ACCIDENT ALERT SYSTEM                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────┐         ┌──────────────────┐
│   VEHICLE LAYER     │         │   NETWORK LAYER  │
├─────────────────────┤         ├──────────────────┤
│ • Airbag Sensor     │────────▶│ • GSM/4G Module  │
│ • Microcontroller   │         │ • Cellular Data  │
│ • GPS Module        │         │ • Internet Link  │
│ • Power Management  │         │ • Fallback Queue │
└─────────────────────┘         └──────────────────┘
          │                             │
          │                             │
          └─────────────────┬───────────┘
                            ▼
                ┌──────────────────────────┐
                │   CLOUD BACKEND          │
                ├──────────────────────────┤
                │ • Alert Processing      │
                │ • Ambulance Matching    │
                │ • Data Storage          │
                │ • Notification Service  │
                └──────────────────────────┘
                            │
                ┌───────────┴────────────┐
                ▼                        ▼
        ┌─────────────────┐     ┌─────────────────┐
        │   MOBILE APP    │     │   DATABASE      │
        ├─────────────────┤     ├─────────────────┤
        │ • Ambulance UI  │     │ • Crash History │
        │ • Navigation    │     │ • User Data     │
        │ • Alerts        │     │ • Locations     │
        └─────────────────┘     └─────────────────┘
```

## Detailed Component Architecture

### 1. Vehicle Hardware Layer

**Embedded System (Arduino/ESP32)**
- Continuously monitors airbag sensor
- Processes sensor signals
- Calculates impact severity using accelerometer data
- Manages GPS location capture
- Handles cellular communication

**Key Modules:**
```
Airbag Sensor ──▶ Signal Processor ──▶ Validation Logic
                                           │
                                           ▼
                                    ┌─────────────┐
                                    │ Severity    │
GPS Module ──────────────┐          │ Assessment  │
                          ├────────▶│   Engine    │
Accelerometer ────────────┘         └─────────────┘
                                           │
                                           ▼
                                    Data Transmission
                                    (GSM/4G Module)
```

### 2. Transmission Layer

**Network Connectivity:**
- Primary: 4G LTE with automatic failover
- Secondary: GSM/2G for remote areas
- Queue Management: Local storage for offline messages
- Message Format: Compact JSON with minimal payload (~200 bytes)

**Failover Strategy:**
```
Crash Detected
      │
      ▼
Try 4G Transmission
      │
   ┌──┴──┐
   │     │
Success  Fail
   │     │
   │     ▼
   │  Try GSM
   │     │
   │  ┌──┴──┐
   │  │     │
   │ Success Fail
   │  │     │
   │  │     ▼
   │  │  Queue Locally
   │  │  (Max 24hrs)
   │  │     │
   │  │  Retry when
   │  │  connected
   ▼  ▼
  Send to Cloud
```

### 3. Cloud Backend Architecture

**API Server**
- RESTful API for device communication
- Crash report ingestion
- Real-time WebSocket support for live updates
- Rate limiting & DDoS protection

**Geolocation Service**
- Queries ambulance locations from database
- Calculates distance to accident site
- Ranks nearby ambulances by:
  - Distance
  - Availability status
  - Current load

**Notification Service**
- Integrates with Firebase Cloud Messaging (FCM)
- Fallback push notification system
- Retry mechanism for failed deliveries

**Data Flow:**
```
Device Alert
      │
      ▼
┌──────────────────┐
│ Alert Receiver   │
│ API Endpoint     │
└──────────────────┘
      │
      ▼
┌──────────────────┐
│ Validation       │
│ • Crash check    │
│ • Location valid │
└──────────────────┘
      │
      ▼
┌──────────────────┐
│ Database Query   │
│ Get ambulances   │
└──────────────────┘
      │
      ▼
┌──────────────────┐
│ Geolocation      │
│ Algorithm        │
│ (Nearest 5)      │
└──────────────────┘
      │
      ▼
┌──────────────────────────────┐
│ Notification Dispatch        │
│ • Send to app                │
│ • Log attempt                │
│ • Set timeout                │
└──────────────────────────────┘
      │
      ▼
Driver Mobile App
```

### 4. Database Schema

**Core Tables:**

```sql
-- Accidents
CREATE TABLE crashes (
  id UUID PRIMARY KEY,
  device_id VARCHAR,
  latitude DECIMAL,
  longitude DECIMAL,
  severity INT (1-10),
  timestamp TIMESTAMP,
  status VARCHAR (detected, notified, arrived, resolved)
);

-- Ambulances
CREATE TABLE ambulances (
  id UUID PRIMARY KEY,
  driver_id VARCHAR,
  current_lat DECIMAL,
  current_lng DECIMAL,
  status VARCHAR (available, assigned, en_route),
  capacity INT,
  response_time INT
);

-- Drivers
CREATE TABLE drivers (
  id UUID PRIMARY KEY,
  email VARCHAR UNIQUE,
  phone VARCHAR,
  ambulance_id UUID,
  availability BOOLEAN,
  rating DECIMAL,
  total_responses INT
);

-- Assignments
CREATE TABLE assignments (
  id UUID PRIMARY KEY,
  crash_id UUID,
  ambulance_id UUID,
  driver_id UUID,
  assigned_at TIMESTAMP,
  accepted_at TIMESTAMP,
  arrived_at TIMESTAMP,
  response_time INT
);
```

### 5. Mobile App Architecture

**Screens & Navigation:**
```
┌─────────────────────────────┐
│     Splash / Login          │
└──────────────┬──────────────┘
               │
               ▼
┌─────────────────────────────┐
│   Dashboard / Home          │
│  ┌────────────────────────┐ │
│  │ Status: Online/Offline │ │
│  │ Current Location       │ │
│  │ Alerts: 0              │ │
│  └────────────────────────┘ │
└──────────────┬──────────────┘
         │     │     │
    ┌────┘     │     └────┐
    ▼          ▼          ▼
┌────────┐ ┌────────┐ ┌────────┐
│ Alert  │ │Profile │ │History │
│ Screen │ │ Screen │ │ Screen │
└────────┘ └────────┘ └────────┘
```

**Real-Time Communication:**
```
Mobile App
    │
    ├─► Firebase Cloud Messaging (FCM)
    │   └─ High priority notifications
    │
    ├─► WebSocket Connection
    │   └─ Live GPS updates
    │   └─ Real-time navigation
    │
    └─► REST API
        └─ Accept/Decline alert
        └─ Status updates
```

### 6. Deployment Architecture

**Production Deployment:**
```
┌────────────────────────────────────────────────────────────┐
│                     AWS / Cloud Platform                   │
├────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────────────────────────────────────────┐  │
│  │  Load Balancer / API Gateway                        │  │
│  └──────────────────┬──────────────────────────────────┘  │
│                     │                                      │
│     ┌───────────────┼───────────────┐                     │
│     │               │               │                     │
│     ▼               ▼               ▼                     │
│  ┌──────┐      ┌──────┐       ┌──────┐                   │
│  │Pod 1 │      │Pod 2 │       │Pod 3 │  (Kubernetes)    │
│  │(API) │      │(API) │       │(API) │                   │
│  └──────┘      └──────┘       └──────┘                   │
│                     │                                      │
│     ┌───────────────┼───────────────┐                     │
│     │               │               │                     │
│     ▼               ▼               ▼                     │
│  ┌──────────────────────────────────────────┐            │
│  │      PostgreSQL Database (Primary)       │            │
│  │      + Read Replicas                     │            │
│  └──────────────────────────────────────────┘            │
│                     │                                      │
│     ┌───────────────┴───────────────┐                     │
│     ▼                               ▼                     │
│  ┌──────────┐               ┌──────────────┐             │
│  │  Redis   │               │ Firebase     │             │
│  │  Cache   │               │ Messaging    │             │
│  └──────────┘               └──────────────┘             │
│                                                             │
└────────────────────────────────────────────────────────────┘
```

## Data Flow Sequences

### Crash Detection to Ambulance Arrival

```
Timeline: T0 to T10

T0: Crash Occurs
    └─ Airbag deploys
    └─ Sensor detects signal
    
T1: Signal Processing (~100ms)
    └─ Microcontroller processes
    └─ Accelerometer validates
    
T2: Data Preparation (~200ms)
    └─ GPS location captured
    └─ Severity calculated
    └─ JSON packet created
    
T3: Transmission (~500ms)
    └─ GSM/4G module sends
    └─ Cloud receives
    
T4: Alert Processing (~300ms)
    └─ Database query
    └─ Ambulance ranking
    
T5: Notification Dispatch (~500ms)
    └─ FCM sends push
    └─ Driver receives alert
    
T6: Driver Acceptance (~2000ms = ~2s)
    └─ Driver taps "Accept"
    └─ Navigation starts
    
T7-T10: En Route (3-5 minutes)
    └─ Real-time tracking
    └─ Driver navigates
    └─ Ambulance arrives

TOTAL: <10s to notification, ~5-10 min to arrival
```

## Scalability Considerations

**Capacity Planning:**
- Single instance: 1000 alerts/minute
- Kubernetes auto-scaling: Up to 100K alerts/minute
- Database replication for read-heavy workloads
- Message queue for spike handling

**Performance Targets:**
- API response time: <100ms (p99)
- Database query: <50ms
- Push notification delivery: <2s
- Ambulance search algorithm: <300ms

## Security Architecture

```
┌─────────────────────────────────────────────────────┐
│          SECURITY LAYERS                            │
├─────────────────────────────────────────────────────┤
│ 1. Transport Layer                                  │
│    └─ TLS 1.2+ encryption for all communication    │
│                                                     │
│ 2. Authentication Layer                            │
│    └─ OAuth 2.0 for driver apps                    │
│    └─ API keys for embedded devices                │
│                                                     │
│ 3. Data Layer                                       │
│    └─ Encryption at rest (AES-256)                 │
│    └─ Role-based access control                    │
│                                                     │
│ 4. Network Layer                                   │
│    └─ Firewall rules                               │
│    └─ DDoS protection                              │
│    └─ VPC isolation                                │
│                                                     │
│ 5. Application Layer                               │
│    └─ Input validation                             │
│    └─ Rate limiting                                │
│    └─ Audit logging                                │
└─────────────────────────────────────────────────────┘
```

---

**Version**: 1.0  
**Last Updated**: 2025
