# Deployment Guide

## Overview

This guide covers deploying the Smart Accident Alert System to production environments. We support deployment on AWS, Google Cloud, and Azure.

---

## Prerequisites

- Docker & Docker Compose
- Kubernetes cluster (for production)
- PostgreSQL database
- Redis instance
- Firebase account (for push notifications)
- SSL certificates

---

## Local Development Deployment

### Quick Start

```bash
# Clone repository
git clone https://github.com/your-org/smart-accident-alert.git
cd Smart-Accident-Alert-System

# Start services
docker-compose -f config/docker-compose.yml up -d

# Check status
docker-compose -f config/docker-compose.yml ps

# View logs
docker-compose -f config/docker-compose.yml logs -f backend
```

### Access Services

- **API**: http://localhost:5000
- **Database**: localhost:5432
- **Redis**: localhost:6379
- **Nginx**: http://localhost:80

### Cleanup

```bash
# Stop services
docker-compose -f config/docker-compose.yml down

# Remove volumes (WARNING: deletes data)
docker-compose -f config/docker-compose.yml down -v
```

---

## Staging Deployment (AWS EC2)

### 1. Setup EC2 Instance

```bash
# Launch EC2 instance (Ubuntu 22.04 LTS)
# - Instance type: t3.large (recommended)
# - Storage: 100GB gp3
# - Security group: Allow 80, 443, 5000

# SSH into instance
ssh -i your-key.pem ubuntu@your-instance-ip

# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Add user to docker group
sudo usermod -aG docker ubuntu

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Install other dependencies
sudo apt install -y postgresql-client git nginx
```

### 2. Setup Environment

```bash
# Clone repository
git clone https://github.com/your-org/smart-accident-alert.git
cd Smart-Accident-Alert-System

# Create production environment file
cp config/development.env config/staging.env

# Edit configuration
nano config/staging.env
# Update:
# - DATABASE_URL (RDS endpoint)
# - REDIS_URL (ElastiCache endpoint)
# - API_KEY (secure key)
# - JWT_SECRET_KEY (secure key)
# - Firebase credentials
```

### 3. Setup RDS Database

```bash
# Using AWS CLI
aws rds create-db-instance \
    --db-instance-identifier smart-alert-staging \
    --db-instance-class db.t3.small \
    --engine postgres \
    --master-username admin \
    --master-user-password <CHANGE_ME> \
    --allocated-storage 100

# Wait for database to be ready, then run migrations
psql postgresql://admin:password@smart-alert-staging.xyz.us-east-1.rds.amazonaws.com/smart_alert < backend/database/schema.sql
```

### 4. Deploy Backend

```bash
# Build image
docker build -t smart-alert-backend:staging -f backend/Dockerfile backend/

# Tag for ECR
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 123456789.dkr.ecr.us-east-1.amazonaws.com
docker tag smart-alert-backend:staging 123456789.dkr.ecr.us-east-1.amazonaws.com/smart-alert-backend:staging
docker push 123456789.dkr.ecr.us-east-1.amazonaws.com/smart-alert-backend:staging

# Update docker-compose for staging
docker-compose -f config/docker-compose.yml --env-file config/staging.env up -d

# Verify
curl http://localhost:5000/health
```

### 5. Setup Nginx Reverse Proxy

```bash
# Create Nginx config
sudo nano /etc/nginx/sites-available/smart-alert

# Add configuration:
upstream backend {
    server localhost:5000;
}

server {
    listen 80;
    server_name staging.smartalert.com;

    # Redirect HTTP to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name staging.smartalert.com;

    ssl_certificate /etc/letsencrypt/live/staging.smartalert.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/staging.smartalert.com/privkey.pem;

    client_max_body_size 10M;

    location / {
        proxy_pass http://backend;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /socket.io {
        proxy_pass http://backend/socket.io;
        proxy_http_version 1.1;
        proxy_buffering off;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "Upgrade";
    }
}

# Enable site
sudo ln -s /etc/nginx/sites-available/smart-alert /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Setup SSL with Let's Encrypt
sudo certbot certonly --webroot -w /var/www/html -d staging.smartalert.com
```

---

## Production Deployment (Kubernetes)

### 1. Setup EKS Cluster

```bash
# Create EKS cluster using eksctl
eksctl create cluster --name smart-alert-prod --region us-east-1 --nodes 3 --node-type t3.medium

# Configure kubectl
aws eks update-kubeconfig --name smart-alert-prod --region us-east-1

# Verify cluster
kubectl get nodes
```

### 2. Setup Database & Cache

```bash
# Create RDS database
aws rds create-db-instance \
    --db-instance-identifier smart-alert-prod \
    --db-instance-class db.t3.medium \
    --engine postgres \
    --master-username admin \
    --master-user-password <CHANGE_ME> \
    --allocated-storage 500 \
    --multi-az

# Create ElastiCache
aws elasticache create-cache-cluster \
    --cache-cluster-id smart-alert-prod \
    --cache-node-type cache.t3.small \
    --engine redis \
    --num-cache-nodes 1
```

### 3. Create Kubernetes Manifests

```yaml
# backend-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: smart-alert-backend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: smart-alert-backend
  template:
    metadata:
      labels:
        app: smart-alert-backend
    spec:
      containers:
      - name: backend
        image: 123456789.dkr.ecr.us-east-1.amazonaws.com/smart-alert-backend:latest
        ports:
        - containerPort: 5000
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: smart-alert-secrets
              key: database-url
        - name: REDIS_URL
          valueFrom:
            secretKeyRef:
              name: smart-alert-secrets
              key: redis-url
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 5000
          initialDelaySeconds: 30
          periodSeconds: 10
---
apiVersion: v1
kind: Service
metadata:
  name: smart-alert-backend
spec:
  selector:
    app: smart-alert-backend
  ports:
  - protocol: TCP
    port: 80
    targetPort: 5000
  type: LoadBalancer
```

### 4. Deploy to Kubernetes

```bash
# Create secrets
kubectl create secret generic smart-alert-secrets \
  --from-literal=database-url=$DATABASE_URL \
  --from-literal=redis-url=$REDIS_URL \
  --from-literal=api-key=$API_KEY

# Create namespace
kubectl create namespace smart-alert

# Deploy
kubectl apply -f k8s/backend-deployment.yaml -n smart-alert

# Verify deployment
kubectl get deployments -n smart-alert
kubectl get pods -n smart-alert

# Check service
kubectl get service smart-alert-backend -n smart-alert
```

### 5. Setup Ingress

```yaml
# ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: smart-alert-ingress
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - api.smartalert.com
    secretName: smart-alert-tls
  rules:
  - host: api.smartalert.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: smart-alert-backend
            port:
              number: 80
```

---

## Monitoring & Logging

### Setup Prometheus

```bash
# Create Prometheus ConfigMap
kubectl create configmap prometheus-config --from-file=prometheus.yml -n smart-alert

# Deploy Prometheus
kubectl apply -f k8s/prometheus.yaml -n smart-alert

# Access Prometheus
kubectl port-forward -n smart-alert service/prometheus 9090:9090
```

### Setup Logging

```bash
# Install Fluentd
helm repo add fluent https://fluent.github.io/helm-charts
helm install fluent-bit fluent/fluent-bit -n smart-alert

# Configure to send logs to CloudWatch
# Update values.yaml with AWS credentials
```

### CloudWatch Dashboards

```bash
# Create dashboard
aws cloudwatch put-dashboard --dashboard-name SmartAlertProd \
  --dashboard-body file://dashboards/production.json
```

---

## Scaling & Auto-Scaling

### Horizontal Pod Autoscaler

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: smart-alert-backend-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: smart-alert-backend
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

---

## Backup & Disaster Recovery

### Database Backups

```bash
# Enable automated backups
aws rds modify-db-instance \
    --db-instance-identifier smart-alert-prod \
    --backup-retention-period 30 \
    --preferred-backup-window "03:00-04:00"

# Manual snapshot
aws rds create-db-snapshot \
    --db-instance-identifier smart-alert-prod \
    --db-snapshot-identifier smart-alert-prod-backup-$(date +%s)
```

### Redis Backups

```bash
# Enable automatic backups
aws elasticache modify-cache-cluster \
    --cache-cluster-id smart-alert-prod \
    --snapshot-retention-limit 30
```

---

## Security Checklist

- [ ] Enable SSL/TLS encryption
- [ ] Setup WAF (Web Application Firewall)
- [ ] Enable API authentication
- [ ] Configure security groups
- [ ] Enable database encryption
- [ ] Setup audit logging
- [ ] Enable DDoS protection
- [ ] Configure rate limiting
- [ ] Setup secrets management
- [ ] Enable monitoring & alerts

---

## Rollback Procedure

```bash
# Kubernetes rollback
kubectl rollout history deployment/smart-alert-backend -n smart-alert
kubectl rollout undo deployment/smart-alert-backend -n smart-alert --to-revision=2

# Docker rollback
docker pull 123456789.dkr.ecr.us-east-1.amazonaws.com/smart-alert-backend:previous
docker-compose up -d
```

---

## Post-Deployment Verification

```bash
# Health checks
curl https://api.smartalert.com/health

# Database connectivity
psql $DATABASE_URL -c "SELECT version();"

# Redis connectivity
redis-cli -u $REDIS_URL ping

# API functionality
curl -X GET https://api.smartalert.com/v1/crash/list \
  -H "Authorization: Bearer $JWT_TOKEN"

# Performance test
ab -n 1000 -c 100 https://api.smartalert.com/health
```

---

**Version**: 1.0  
**Last Updated**: 2025
