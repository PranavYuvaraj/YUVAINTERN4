# Deployment

(Original pre-alpha deployment notes: `docs/legacy_design/DEPLOYMENT.md`.) **Nothing here has been deployed or verified by this package.**

## Prerequisites
Run `python -m src.train` so that `models/accident_severity_model.joblib` and `models/model_metadata.json` exist, run `pytest`, and commit the model files (they are not git-ignored). Use the same scikit-learn version in production as in `models/model_metadata.json`.

## Option A - Render (free tier, two web services)
1. Push the repository to GitHub. 2. Render -> New -> Blueprint -> select the repo (uses `render.yaml`), or create two Web Services manually.
3. API service: build `pip install -r requirements-api.txt`, start `uvicorn api.main:app --host 0.0.0.0 --port $PORT`, health check `/health`.
4. Dashboard service: build `pip install -r requirements.txt`, start `streamlit run frontend/app.py --server.port $PORT --server.address 0.0.0.0 --server.headless true`.
5. Set `API_URL` (dashboard) to the API's public URL; set `CORS_ORIGINS` (API) to the dashboard's URL. Free instances sleep when idle; the first request can be slow.
6. Verify: open `<api>/health`, `<api>/docs`, make a prediction in the dashboard. Only then record the URLs in the README.

## Option B - Docker (API)
```
docker build -t accident-api .
docker run -p 8000:8000 -e CORS_ORIGINS=http://localhost:8501 accident-api
```
(Dockerfile not built in the authoring environment - verify on your machine.)

## Production guidance
No wildcard CORS; HTTPS only; add authentication and rate limiting; pin dependency versions; keep logs free of personal data; monitor input drift; keep the human-verification requirement.
