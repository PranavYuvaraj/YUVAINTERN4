# GitHub repository description (~200 words)

**Smart Accident Alert System - ML Accident Severity Prediction.** An end-to-end educational machine-learning project that predicts road-collision severity (Low, Moderate, High) from conditions such as speed limit, road type, light, weather, surface, area type and time of day. It builds on a pre-alpha accident-alert design and adds the ML component that design only listed as future work.

The pipeline is built with scikit-learn: feature cleaning and engineering, imputation, one-hot encoding, and a comparison of Logistic Regression, Decision Tree and Random Forest using stratified cross-validation and macro-F1 to handle class imbalance. The best model is saved as one Joblib pipeline and served by a FastAPI backend with Pydantic validation, health and model-info endpoints and Swagger docs. A Streamlit dashboard calls the API, shows probabilities, session history and model performance. Automated pytest tests cover preprocessing, model loading, API validation and frontend/API integration.

Deployment files for Docker and Render are included, with environment-based configuration and no committed secrets. Training uses the UK DfT STATS19 open data; EDA and evaluation reports are generated from real runs.

**Limitations:** context-only features (no impact or sensor data), UK data, rare fatal class, and no emergency dispatch. It is not a certified safety system.

Topics: machine-learning, scikit-learn, fastapi, streamlit, joblib, road-safety, classification
