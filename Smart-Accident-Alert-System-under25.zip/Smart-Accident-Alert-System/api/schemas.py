"""Pydantic request/response models. Allowed values come from src.config."""
from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

from src import config as C


def _check_code(feature: str, value: Optional[int]):
    if value is not None and value not in C.FEATURE_CODES[feature]:
        raise ValueError(f"{feature}={value} is not a valid code. Allowed: {sorted(C.FEATURE_CODES[feature])}")
    return value


class PredictionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid", json_schema_extra={"example": {
        "speed_limit": 30, "hour": 18, "road_type": 6, "light_conditions": 4,
        "weather_conditions": 2, "road_surface_conditions": 2, "urban_or_rural_area": 1,
        "number_of_vehicles": 2, "day_of_week": 6, "month": 11, "junction_detail": 3, "first_road_class": 3}})

    # required
    speed_limit: int = Field(..., description="Posted speed limit in mph (20,30,40,50,60,70)")
    hour: int = Field(..., ge=C.HOUR_RANGE[0], le=C.HOUR_RANGE[1])
    road_type: int
    light_conditions: int
    weather_conditions: int
    road_surface_conditions: int
    urban_or_rural_area: int
    # optional (imputed when omitted)
    number_of_vehicles: Optional[int] = Field(None, ge=C.VEHICLES_RANGE[0], le=C.VEHICLES_RANGE[1])
    day_of_week: Optional[int] = None
    month: Optional[int] = Field(None, ge=C.MONTH_RANGE[0], le=C.MONTH_RANGE[1])
    junction_detail: Optional[int] = None
    first_road_class: Optional[int] = None

    @field_validator("speed_limit")
    @classmethod
    def _speed(cls, v):
        if v not in C.VALID_SPEED_LIMITS:
            raise ValueError(f"speed_limit must be one of {C.VALID_SPEED_LIMITS}")
        return v

    @field_validator("road_type", "light_conditions", "weather_conditions", "road_surface_conditions",
                     "urban_or_rural_area", "day_of_week", "junction_detail", "first_road_class")
    @classmethod
    def _codes(cls, v, info):
        return _check_code(info.field_name, v)


class PredictionResponse(BaseModel):
    severity: str
    confidence: float
    probabilities: dict[str, float]
    imputed_fields: list[str]
    model_name: str
    disclaimer: str


class HealthResponse(BaseModel):
    status: str
    model_loaded: bool
    detail: Optional[str] = None


class ModelInfoResponse(BaseModel):
    model_name: str
    classes: list[str]
    features: list[str]
    trained_at: Optional[str] = None
    dataset_file: Optional[str] = None
    n_train: Optional[int] = None
    n_test: Optional[int] = None
    best_params: Optional[dict] = None
    test_metrics: Optional[dict] = None
    comparison: Optional[dict] = None
    feature_options: dict[str, dict[int, str]]
    disclaimer: str
