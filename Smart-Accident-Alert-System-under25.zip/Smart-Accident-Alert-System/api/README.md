# api/ - FastAPI service
`main.py` (app, endpoints, CORS, model loading) and `schemas.py` (Pydantic request/response models; allowed values come from `src/config.py`).
Run: `uvicorn api.main:app --reload --port 8000` - Swagger: `/docs`.
Environment: `CORS_ORIGINS`, `MODEL_PATH`, `MODEL_METADATA_PATH` (see `.env.example`). Without a model file the API still starts: `/health` reports `degraded` and `/predict` returns 503.
