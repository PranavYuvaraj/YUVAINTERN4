"""FastAPI service for accident-severity prediction.

Run:  uvicorn api.main:app --reload
Docs: http://127.0.0.1:8000/docs
"""
from __future__ import annotations

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from api.schemas import (HealthResponse, ModelInfoResponse, PredictionRequest, PredictionResponse)
from src import config as C
from src.predict import ModelNotAvailableError, load_model, predict_one

log = logging.getLogger("accident-api")


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.bundle, app.state.load_error = None, None
    try:
        app.state.bundle = load_model(os.getenv("MODEL_PATH", C.MODEL_PATH),
                                      os.getenv("MODEL_METADATA_PATH", C.METADATA_PATH))
        log.info("Model loaded")
    except ModelNotAvailableError as exc:
        app.state.load_error = str(exc)
        log.error("Model not loaded: %s", exc)
    yield


app = FastAPI(
    title="Smart Accident Alert System - Severity API",
    version="2.0.0",
    description="Predicts accident severity (Low / Moderate / High) from road and environment conditions. "
                + C.DISCLAIMER,
    lifespan=lifespan,
)

origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:8501,http://127.0.0.1:8501").split(",") if o.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_methods=["GET", "POST"], allow_headers=["Content-Type"])


def _bundle():
    if app.state.bundle is None:
        raise HTTPException(status_code=503, detail=app.state.load_error or "Model not loaded")
    return app.state.bundle


@app.get("/")
def root():
    return {"service": "Smart Accident Alert System - Severity API", "version": app.version,
            "docs": "/docs", "endpoints": ["/health", "/predict", "/model-info"], "disclaimer": C.DISCLAIMER}


@app.get("/health", response_model=HealthResponse)
def health():
    ok = app.state.bundle is not None
    return HealthResponse(status="ok" if ok else "degraded", model_loaded=ok, detail=app.state.load_error)


@app.post("/predict", response_model=PredictionResponse)
def predict(req: PredictionRequest):
    bundle = _bundle()
    features = req.model_dump()
    imputed = [k for k in C.RAW_FEATURES if features.get(k) is None]
    try:
        result = predict_one(bundle, features)
    except Exception as exc:  # never leak internals to the client
        log.exception("Prediction failed")
        raise HTTPException(status_code=500, detail="Prediction failed") from exc
    return PredictionResponse(**result, imputed_fields=imputed,
                              model_name=bundle.metadata.get("model_name", type(bundle.pipeline[-1]).__name__),
                              disclaimer=C.DISCLAIMER)


@app.get("/model-info", response_model=ModelInfoResponse)
def model_info():
    b = _bundle()
    m = b.metadata
    name = m.get("model_name", type(b.pipeline[-1]).__name__)
    return ModelInfoResponse(
        model_name=name, classes=list(b.pipeline.classes_) if not m else m.get("classes", C.CLASS_ORDER),
        features=C.RAW_FEATURES, trained_at=m.get("trained_at"), dataset_file=m.get("dataset_file"),
        n_train=m.get("n_train"), n_test=m.get("n_test"), best_params=m.get("best_params"),
        test_metrics=(m.get("metrics") or {}).get(name), comparison=m.get("metrics"),
        feature_options=C.FEATURE_CODES, disclaimer=C.DISCLAIMER)
