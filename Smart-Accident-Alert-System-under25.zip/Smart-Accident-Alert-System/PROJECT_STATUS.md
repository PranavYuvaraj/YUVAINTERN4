# Project status

**Version:** 2.0.0-ml-prototype (previous: v1.0.0 pre-alpha, design documents only)

## Implemented and verified (automated tests, synthetic fixtures)
- Config-driven preprocessing, feature engineering, training, evaluation, EDA and report generators
- Joblib save/reload with prediction-equality check
- FastAPI (`/`, `/health`, `/predict`, `/model-info`), Pydantic validation, CORS from environment, 503 handling
- Streamlit dashboard (Predict, Model performance, About) verified headlessly against a live API
- pytest suite - see `reports/test_results.txt`

## Not yet done (needs the real dataset)
- Download the DfT STATS19 CSV (`dataset/README.md`), run `python -m src.eda`, `python -m src.train`, `python -m src.build_docs`
- Review `src/config.py` code tables against the dataset's field guide (training prints discrepancies)
- Fill author name, capture screenshots with `scripts/capture_screenshots.py`, deploy (optional) and record verified URLs

## Not implemented (original design ideas)
Hardware/sensor integration, GPS, ambulance matching, notifications, database, authentication, mobile app. These are future scope only.

See `PROJECT_PROGRESS.md` for the exact next actions.
