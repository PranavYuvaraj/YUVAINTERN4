"""Streamlit dashboard (dark card layout). Talks to the FastAPI backend only.

Run:  streamlit run frontend/app.py     (API must be running; see API_URL)
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from frontend import api_client as api  # noqa: E402
from src import config as C  # noqa: E402

COLORS = {"Low": "#22c55e", "Moderate": "#f59e0b", "High": "#ef4444"}
GUIDANCE = {"Low": "Conditions resemble collisions that were mostly recorded as slight.",
            "Moderate": "Conditions resemble a mix that includes serious collisions.",
            "High": "Conditions resemble collisions with a higher share of fatal outcomes."}
OPTIONAL = ["number_of_vehicles", "day_of_week", "month", "junction_detail", "first_road_class"]

st.set_page_config(page_title="Smart Accident Alert System", page_icon="🚨", layout="wide")
st.markdown("""<style>
.card{background:#161a23;border:1px solid #2a303c;border-radius:14px;padding:1.1rem 1.3rem;margin-bottom:1rem}
.card h4{margin:0 0 .8rem 0;font-size:.82rem;letter-spacing:.08em;text-transform:uppercase;color:#cbd5e1}
.kv{color:#94a3b8;margin:.28rem 0;font-size:.93rem}.kv b{color:#f1f5f9}
.badge{padding:1rem 1.3rem;border-radius:12px;color:#fff;font-size:1.55rem;font-weight:700}
.bar-row{margin:.55rem 0}.bar-label{display:flex;justify-content:space-between;font-size:.9rem;color:#e2e8f0}
.bar-label span:last-child{font-family:Consolas,monospace}
.bar{height:9px;background:#252b38;border-radius:6px;overflow:hidden;margin-top:.25rem}
.bar>div{height:100%;border-radius:6px}
.chip{display:inline-block;padding:.18rem .65rem;margin:.18rem .25rem .18rem 0;border-radius:999px;font-size:.78rem;font-weight:600}
.chip.ok{background:#1b2a24;color:#4ade80;border:1px solid #24503a}
.chip.no{background:#2a1a1d;color:#f87171;border:1px solid #5a2630}
.small{color:#94a3b8;font-size:.85rem}
</style>""", unsafe_allow_html=True)
st.session_state.setdefault("history", [])


def card(title: str, body: str) -> None:
    st.markdown(f'<div class="card"><h4>{title}</h4>{body}</div>', unsafe_allow_html=True)


def kv(label: str, value) -> str:
    return f'<div class="kv">• {label}: <b>{value}</b></div>'


def chip(text: str, ok: bool) -> str:
    return f'<span class="chip {"ok" if ok else "no"}">{"✓" if ok else "✗"} {text}</span>'


def bars(probs: dict) -> str:
    out = ""
    for c in C.CLASS_ORDER:
        p = probs[c]
        out += (f'<div class="bar-row"><div class="bar-label"><span>{c}</span><span>{p:.1%}</span></div>'
                f'<div class="bar"><div style="width:{p * 100:.1f}%;background:{COLORS[c]}"></div></div></div>')
    return out


def label(feature: str, value) -> str:
    return "not provided" if value is None else C.FEATURE_CODES[feature].get(value, str(value))


@st.cache_data(ttl=60, show_spinner=False)
def _info():
    return api.get_model_info()


def _select(text, feature, optional=False, index=0):
    opts = ([("(not known)", None)] if optional else []) + [(v, k) for k, v in C.FEATURE_CODES[feature].items()]
    return dict(opts)[st.selectbox(text, [o[0] for o in opts], index=index, key=feature)]


# ------------------------------------------------------------------ sidebar
st.sidebar.title("🚨 Accident Severity")
page = st.sidebar.radio("Navigate", ["Predict", "Model performance", "About & limitations"])
try:
    h = api.get_health()
    (st.sidebar.success if h["model_loaded"] else st.sidebar.error)(
        f"API: {h['status']}" + ("" if h["model_loaded"] else " - model not loaded"))
    api_ok = h["model_loaded"]
except api.ApiError as e:
    st.sidebar.error("API unreachable"); st.sidebar.caption(str(e)); api_ok = False
st.sidebar.caption(C.DISCLAIMER)

st.title("Smart Accident Alert System")
st.caption("Machine-learning accident severity prediction (Low / Moderate / High) from road and environment conditions.")

# ------------------------------------------------------------------ predict
if page == "Predict":
    if not api_ok:
        st.warning("The prediction API is not available. Start it with `uvicorn api.main:app` and check `API_URL`.")
    with st.form("predict_form"):
        c1, c2, c3 = st.columns(3)
        with c1:
            st.subheader("Road")
            speed = st.selectbox("Speed limit (mph)", C.VALID_SPEED_LIMITS, index=1)
            road_type = _select("Road type", "road_type", index=3)
            urban = _select("Area", "urban_or_rural_area")
            junction = _select("Junction (optional)", "junction_detail", optional=True)
            road_class = _select("Road class (optional)", "first_road_class", optional=True)
        with c2:
            st.subheader("Conditions")
            light = _select("Light conditions", "light_conditions")
            weather = _select("Weather", "weather_conditions", index=1)
            surface = _select("Road surface", "road_surface_conditions")
        with c3:
            st.subheader("Time & vehicles")
            hour = st.slider("Hour of day", 0, 23, 17)
            day = _select("Day of week (optional)", "day_of_week", optional=True)
            month = st.selectbox("Month (optional)", [None] + list(range(1, 13)),
                                 format_func=lambda m: "(not known)" if m is None else str(m))
            vehicles = st.number_input("Vehicles involved (0 = not known)", 0, C.VEHICLES_RANGE[1], 0)
        go = st.form_submit_button("Predict severity", type="primary", width="stretch")

    if go:
        payload = {"speed_limit": speed, "hour": hour, "road_type": road_type, "light_conditions": light,
                   "weather_conditions": weather, "road_surface_conditions": surface, "urban_or_rural_area": urban,
                   "number_of_vehicles": vehicles or None, "day_of_week": day, "month": month,
                   "junction_detail": junction, "first_road_class": road_class}
        try:
            with st.spinner("Contacting the model..."):
                res = api.predict(payload)
        except api.ApiError as e:
            st.error(str(e))
        else:
            st.session_state.history.insert(0, {
                "Severity": res["severity"], "Confidence": f"{res['confidence']:.0%}", "Speed": speed, "Hour": hour,
                "Light": label("light_conditions", light), "Weather": label("weather_conditions", weather),
                "Area": label("urban_or_rural_area", urban)})
            left, right = st.columns(2)
            with left:
                st.markdown(f'<div class="badge" style="background:{COLORS[res["severity"]]}">'
                            f'Predicted severity: {res["severity"]}</div>', unsafe_allow_html=True)
                st.markdown(f'<p class="small" style="margin-top:.7rem">{GUIDANCE[res["severity"]]}<br>'
                            f'Model: {res["model_name"]} · confidence {res["confidence"]:.1%}</p>', unsafe_allow_html=True)
                st.info(res["disclaimer"])
            with right:
                card("Severity probabilities", bars(res["probabilities"]))
            st.markdown("##### INPUT EVIDENCE")
            e1, e2 = st.columns(2)
            with e1:
                card("Road & environment",
                     kv("Speed limit", f"{speed} mph") + kv("Road type", label("road_type", road_type))
                     + kv("Area", label("urban_or_rural_area", urban)) + kv("Light", label("light_conditions", light))
                     + kv("Weather", label("weather_conditions", weather))
                     + kv("Road surface", label("road_surface_conditions", surface)))
            with e2:
                card("Time & optional details",
                     kv("Hour", f"{hour}:00") + kv("Day", label("day_of_week", day))
                     + kv("Month", month or "not provided") + kv("Vehicles", vehicles or "not provided")
                     + kv("Junction", label("junction_detail", junction))
                     + kv("Road class", label("first_road_class", road_class)))
            card("Data completeness",
                 "".join(chip(f.replace("_", " "), f not in res["imputed_fields"]) for f in C.RAW_FEATURES)
                 + '<div class="small" style="margin-top:.5rem">✗ = not supplied, filled in by the model with the '
                   'training median / most frequent value.</div>')

    st.subheader("Prediction history (this session)")
    if st.session_state.history:
        st.dataframe(pd.DataFrame(st.session_state.history), width="stretch", hide_index=True)
        if st.button("Clear history"):
            st.session_state.history = []; st.rerun()
    else:
        st.caption("No predictions yet.")

# -------------------------------------------------------------- performance
elif page == "Model performance":
    try:
        info = _info()
    except api.ApiError as e:
        st.error(str(e)); st.stop()
    st.subheader(f"Selected model: {info['model_name']}")
    if info.get("n_train"):
        st.caption(f"Trained {info.get('trained_at')} on {info.get('dataset_file')} "
                   f"({info['n_train']:,} train / {info['n_test']:,} test rows).")
    comp = info.get("comparison") or {}
    if comp:
        table = pd.DataFrame({n: {"Accuracy": m["accuracy"], "Macro precision": m["macro_precision"],
                                  "Macro recall": m["macro_recall"], "Macro F1": m["macro_f1"],
                                  "ROC-AUC (OvR)": m["roc_auc_ovr_macro"]} for n, m in comp.items()}).T
        st.dataframe(table.style.format("{:.3f}"), width="stretch")
        st.bar_chart(table[["Accuracy", "Macro F1", "Macro recall"]])
    tm = info.get("test_metrics")
    if tm:
        a, b = st.columns(2)
        with a:
            st.markdown("**Per-class metrics (test set)**")
            st.dataframe(pd.DataFrame(tm["per_class"]).T.style.format(
                {"precision": "{:.3f}", "recall": "{:.3f}", "f1": "{:.3f}", "support": "{:,.0f}"}))
        with b:
            st.markdown("**Confusion matrix**")
            st.dataframe(pd.DataFrame(tm["confusion_matrix"], index=[f"Actual {c}" for c in C.CLASS_ORDER],
                                      columns=[f"Pred {c}" for c in C.CLASS_ORDER]))
    st.caption("Full interpretation: reports/model_evaluation.md and reports/eda_findings.md in the repository.")

# --------------------------------------------------------------------- about
else:
    card("About this project",
         '<div class="kv">An educational ML prototype built on the Smart Accident Alert System design. A scikit-learn '
         'pipeline trained on UK DfT STATS19 collision records estimates collision severity from road, time and '
         'weather conditions. This Streamlit UI calls a FastAPI service that loads the Joblib model.</div>')
    card("Limitations",
         kv("Inputs", "road/environment context only - no impact force, vehicle speed or occupant data")
         + kv("Data", "UK records; may not transfer to other countries")
         + kv("Class balance", "High (fatal) is rare, so High predictions have limited precision/recall")
         + kv("Safety", "not a certified system; no emergency dispatch or notification is performed")
         + kv("Use", "any real use would need human verification"))
