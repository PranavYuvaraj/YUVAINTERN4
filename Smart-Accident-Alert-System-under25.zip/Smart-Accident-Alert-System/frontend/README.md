# frontend/ - Streamlit dashboard
`app.py` (dark card UI: Predict, Model performance, About) and `api_client.py` (HTTP client with user-safe errors).
Run: `streamlit run frontend/app.py`. Set `API_URL` (default `http://127.0.0.1:8000`). Theme: `../.streamlit/config.toml`.
The dashboard never predicts locally; if the API is down it shows an error instead of a result.
