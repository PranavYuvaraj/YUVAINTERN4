"""Thin HTTP client used by the Streamlit dashboard (also tested separately)."""
from __future__ import annotations

import os

import requests

API_URL = os.getenv("API_URL", "http://127.0.0.1:8000").rstrip("/")
TIMEOUT = float(os.getenv("API_TIMEOUT", "15"))


class ApiError(RuntimeError):
    """API unreachable or returned an error; message is safe to show to users."""


def _call(method: str, path: str, base_url: str | None = None, **kw):
    url = f"{(base_url or API_URL).rstrip('/')}{path}"
    try:
        r = requests.request(method, url, timeout=TIMEOUT, **kw)
    except requests.RequestException as exc:
        raise ApiError(f"Cannot reach the API at {url}. Is it running? ({type(exc).__name__})") from exc
    if r.status_code == 422:
        detail = r.json().get("detail", [])
        msgs = "; ".join(f"{'.'.join(map(str, d.get('loc', [])[1:]))}: {d.get('msg')}" for d in detail)
        raise ApiError(f"Invalid input - {msgs}")
    if r.status_code == 503:
        raise ApiError(f"Model not available on the server: {r.json().get('detail')}")
    if not r.ok:
        raise ApiError(f"API error {r.status_code}")
    return r.json()


def get_health(base_url=None):
    return _call("GET", "/health", base_url)


def get_model_info(base_url=None):
    return _call("GET", "/model-info", base_url)


def predict(payload: dict, base_url=None):
    return _call("POST", "/predict", base_url, json=payload)
