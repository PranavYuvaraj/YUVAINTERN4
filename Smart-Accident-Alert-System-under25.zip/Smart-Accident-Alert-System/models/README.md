# models/
Created by `python -m src.train`: `accident_severity_model.joblib` (complete fitted pipeline) and `model_metadata.json` (features, metrics, dataset hash, library versions).
Commit both for deployment. Only load model files you created (Joblib is pickle-based) and keep the scikit-learn version the same as in the metadata.
