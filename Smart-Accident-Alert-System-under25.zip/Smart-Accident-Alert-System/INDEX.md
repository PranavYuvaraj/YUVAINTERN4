# Project index
| Path | Purpose |
|---|---|
| `README.md` | Overview, usage, results block (auto-filled) |
| `PROJECT_STATUS.md`, `PROJECT_PROGRESS.md` | Honest status and next actions |
| `QUICKSTART.md`, `CONTRIBUTING.md` | Setup and contribution rules |
| `src/` | ML code (config, preprocessing, features, train, evaluate, eda, predict, build_docs) |
| `api/`, `frontend/` | FastAPI service, Streamlit dashboard |
| `tests/` | pytest suite |
| `dataset/` | Data instructions (CSV git-ignored) |
| `models/` | Fitted pipeline + metadata (after training) |
| `reports/` | Generated EDA/evaluation reports and figures |
| `docs/` | Architecture, API, deployment, report, presentation, Q&A, GitHub description |
| `docs/templates/` | Templates filled by `python -m src.build_docs` |
| `docs/legacy_design/`, `legacy_design/`, `hardware/` | Original pre-alpha design (archived, not implemented) |
| `Dockerfile`, `render.yaml`, `.env.example` | Deployment configuration (unverified) |
