# scripts/
- `run_local.bat` - starts the API and the dashboard in two Windows terminals.
- `capture_screenshots.py` - captures real screenshots of the running dashboard/API into `../screenshots/` (needs Playwright; see `../screenshots/README.md`).
