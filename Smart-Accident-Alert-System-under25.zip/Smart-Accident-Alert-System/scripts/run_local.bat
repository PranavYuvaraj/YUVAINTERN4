@echo off
REM Start API and dashboard in two windows (Windows). Run setup first: python -m venv .venv ^& .venv\Scripts\activate ^& pip install -r requirements.txt
start "API" cmd /k "uvicorn api.main:app --reload --port 8000"
start "Dashboard" cmd /k "streamlit run frontend/app.py"
