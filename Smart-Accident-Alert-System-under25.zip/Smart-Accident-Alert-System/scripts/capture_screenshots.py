"""Capture REAL screenshots of the running dashboard and API docs into screenshots/.

One-time setup (your machine):
    pip install playwright
    python -m playwright install chromium
Then (API and dashboard already running, model trained on the real dataset):
    python scripts/capture_screenshots.py
    python -m src.build_docs          # adds the images to README.md
Options: --dashboard URL (default http://localhost:8501)  --api URL (default http://127.0.0.1:8000)
"""
import argparse
from pathlib import Path

from playwright.sync_api import sync_playwright

OUT = Path(__file__).resolve().parent.parent / "screenshots"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dashboard", default="http://localhost:8501")
    ap.add_argument("--api", default="http://127.0.0.1:8000")
    a = ap.parse_args()
    OUT.mkdir(exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1440, "height": 900})
        page.goto(a.dashboard)
        page.get_by_role("button", name="Predict severity").wait_for(timeout=30000)
        page.screenshot(path=OUT / "01_predict_form.png", full_page=True)
        page.get_by_role("button", name="Predict severity").click()
        page.get_by_text("Predicted severity").first.wait_for(timeout=30000)
        page.wait_for_timeout(800)
        page.screenshot(path=OUT / "02_prediction_result.png", full_page=True)
        page.get_by_text("Model performance").first.click()
        page.get_by_text("Selected model").first.wait_for(timeout=30000)
        page.wait_for_timeout(800)
        page.screenshot(path=OUT / "03_model_performance.png", full_page=True)
        page.get_by_text("About & limitations").first.click()
        page.get_by_text("Limitations").first.wait_for(timeout=30000)
        page.screenshot(path=OUT / "04_about_limitations.png", full_page=True)
        page.goto(f"{a.api}/docs")
        page.get_by_text("/predict").first.wait_for(timeout=30000)
        page.screenshot(path=OUT / "05_api_swagger_docs.png", full_page=True)
        browser.close()
    print("Saved:", *sorted(f.name for f in OUT.glob("*.png")))


if __name__ == "__main__":
    main()
