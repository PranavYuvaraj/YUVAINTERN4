# Dataset

**Source (genuine, traceable):** UK Department for Transport (DfT) *Road Safety Data* - STATS19 **collision** table.
Landing page: https://www.gov.uk/government/statistics/road-safety-data (also listed on data.gov.uk). Licence shown on DfT's data catalogue: **Open Government Licence (OGL)** - re-confirm on the page when you download.

## Download (about 20 MB per year) - Windows
Save ONE collision file as `dataset/accident_data.csv`. Direct links published by DfT:
- 2023 (recommended, widely used schema): https://data.dft.gov.uk/road-accidents-safety-data/dft-road-casualty-statistics-collision-2023.csv
- 2022: https://data.dft.gov.uk/road-accidents-safety-data/dft-road-casualty-statistics-collision-2022.csv
- Newest year (2025): https://data.dft.gov.uk/road-accidents-safety-data/dft-road-casualty-statistics-collision-2025.csv
- Last 5 years in one file (about 98 MB) is listed on the landing page.

PowerShell example:
```
Invoke-WebRequest -Uri "https://data.dft.gov.uk/road-accidents-safety-data/dft-road-casualty-statistics-collision-2023.csv" -OutFile "dataset\accident_data.csv"
```
Also download the **data guide** (xlsx) from the landing page and compare its code tables with `src/config.py`.

## Schema note (important)
The latest DfT files appear to list `legacy_collision_severity` and `enhanced_severity_collision` instead of `collision_severity` (seen in DfT's online preview; not verified against a downloaded file). The loader maps `legacy_collision_severity` (1 Fatal, 2 Serious, 3 Slight) to the target and ignores the enhanced field. Read DfT's "severity adjustment guidance" before choosing a year, and state the choice in your report. If a file has neither column, the loader stops with the list of available columns.

## Label mapping and fields
Target: 1 Fatal -> **High**, 2 Serious -> **Moderate**, 3 Slight -> **Low** (a rename, nothing merged).
Inputs: `speed_limit, number_of_vehicles, day_of_week, road_type, junction_detail, first_road_class, light_conditions, weather_conditions, road_surface_conditions, urban_or_rural_area`, plus `hour` (from `time`) and `month` (from `date`).
Excluded on purpose: `number_of_casualties` and police-attendance fields (known only after the event = leakage), coordinates / police force / LSOA (location privacy), identifiers.

Data are anonymised police statistics (no names). The CSV is git-ignored. Cite the DfT and the licence in any publication.
