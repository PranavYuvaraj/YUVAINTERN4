# Contributing to Smart Accident Alert System

Thank you for your interest in contributing to the Smart Accident Alert System! This document provides guidelines and instructions for contributing.

## Code of Conduct

We are committed to providing a welcoming and inclusive environment. Please:
- Be respectful of other contributors
- Provide constructive feedback
- Focus on the code, not the person
- Help others learn and grow

## How to Contribute

### 1. Reporting Bugs

If you find a bug, please create an issue with:
- **Title**: Clear, concise description
- **Description**: What you expected vs. what happened
- **Steps to Reproduce**: How to replicate the issue
- **Environment**: OS, Python version, hardware used
- **Screenshots/Logs**: If applicable

### 2. Suggesting Features

Feature requests should include:
- **Title**: Brief description of the feature
- **Motivation**: Why this feature is needed
- **Implementation Ideas**: How it could be implemented
- **Alternatives**: Other approaches considered

### 3. Submitting Code

#### Setup Development Environment

```bash
# Clone repository
git clone https://github.com/your-org/smart-accident-alert.git
cd Smart-Accident-Alert-System

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r backend/requirements.txt
pip install -r dev-requirements.txt

# Setup pre-commit hooks
pre-commit install
```

#### Development Workflow

```bash
# Create feature branch
git checkout -b feature/your-feature-name

# Make changes
# Write tests
# Format code

# Run tests
pytest tests/

# Run linting
flake8 backend/src
black backend/src
pylint backend/src

# Commit with meaningful messages
git commit -m "feat: add ambulance location tracking"

# Push to your fork
git push origin feature/your-feature-name

# Create Pull Request
```

#### Commit Message Format

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Code style (formatting, missing semicolons, etc)
- `refactor`: Code refactoring
- `perf`: Performance improvements
- `test`: Adding or updating tests
- `chore`: Build process, dependencies, tools

**Examples:**
```
feat(api): add crash severity endpoint
fix(gps): handle timeout in cold start
docs: update hardware setup guide
test: add integration tests for ambulance matching
```

### 4. Code Style

#### Python (Backend)
- Use **PEP 8** style guide
- Line length: Maximum 100 characters
- Use type hints where applicable
- Docstrings for all functions/classes

```python
def process_crash_alert(crash_data: dict) -> str:
    """
    Process incoming crash alert and dispatch ambulance.
    
    Args:
        crash_data: Dictionary containing crash information
        
    Returns:
        Alert ID if successful, raises exception otherwise
        
    Raises:
        ValueError: If crash data is invalid
        ServiceException: If dispatch fails
    """
    # Implementation
    pass
```

#### JavaScript/TypeScript (Frontend)
- Use **ESLint** configuration provided
- **Prettier** for code formatting
- Use TypeScript for type safety
- Meaningful component names

```typescript
interface CrashAlert {
  crashId: string;
  location: Coordinates;
  severity: number;
  timestamp: Date;
}

const processCrashAlert = async (alert: CrashAlert): Promise<void> => {
  // Implementation
};
```

#### C/C++ (Hardware)
- Follow Arduino style guidelines
- Use meaningful variable names
- Add comments for complex logic
- Keep functions small and focused

### 5. Testing Requirements

All code must include tests:

```bash
# Backend tests
cd backend
pytest tests/ --cov=src --cov-report=html

# Frontend tests
cd frontend
pytest

# Hardware tests
cd hardware
pytest tests/
```

**Test Coverage Requirements:**
- Minimum 80% coverage for core modules
- 100% for critical components (crash detection, dispatch)
- All public functions must have tests

**Example Test:**
```python
import pytest
from app.services import dispatch_ambulance

@pytest.fixture
def sample_crash():
    return {
        'latitude': 13.0827,
        'longitude': 80.2707,
        'severity': 8
    }

def test_ambulance_dispatch_success(sample_crash):
    """Test successful ambulance dispatch"""
    result = dispatch_ambulance(sample_crash)
    assert result['status'] == 'dispatched'
    assert 'ambulance_id' in result

def test_ambulance_dispatch_no_available():
    """Test dispatch when no ambulances available"""
    with pytest.raises(ServiceException):
        dispatch_ambulance({'latitude': 0, 'longitude': 0})
```

### 6. Documentation

- Update README if adding new features
- Keep API documentation current
- Add docstrings to all functions
- Include examples in documentation

### 7. Pull Request Process

1. **Fork** the repository
2. **Create** a feature branch
3. **Make** your changes
4. **Write/Update** tests
5. **Update** documentation
6. **Push** to your fork
7. **Create** a Pull Request with:
   - Clear title and description
   - Link to related issue
   - Screenshots/GIFs if UI changes
   - Test coverage report

#### PR Checklist
- [ ] Code follows style guidelines
- [ ] Tests pass locally (`pytest`)
- [ ] Documentation updated
- [ ] No new linting warnings
- [ ] Changes are backward compatible
- [ ] Commit messages are clear

### 8. Code Review Process

- Maintainers will review your PR within 3-5 days
- Address feedback promptly
- Discussion is encouraged
- Once approved, we'll merge your PR

## Development Standards

### Backend (Python/FastAPI)
- Test coverage: ≥80%
- Use logging for debugging
- Handle errors gracefully
- Follow FastAPI/Pydantic conventions; keep feature definitions in `src/config.py`
- Never commit datasets, secrets or `.env` files

### Frontend (Streamlit)
- Component-based architecture
- Proper state management
- Touch-friendly UI (tap targets ≥44x44px)
- Offline capability
- Battery-efficient code

### Hardware (C/C++)
- Efficient memory usage
- Non-blocking operations
- Proper error handling
- Low power consumption
- Extensive comments

## Getting Help

- **Discussions**: GitHub Discussions for general questions
- **Issues**: File bugs and feature requests
- **Email**: development@smartalert.com
- **Slack**: Join our developer community

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

## Resources

- [Project README](README.md)
- [System Architecture](docs/SYSTEM_ARCHITECTURE.md)
- [API Documentation](docs/API_DOCUMENTATION.md)
- [Hardware Setup](hardware/README.md)

---

**Thank you for contributing to making emergency response faster and saving lives! 🚑**
