# Quick start (Windows)
```
python -m venv .venv && .venv\Scripts\activate
pip install -r requirements-dev.txt
# 1. download a DfT collision CSV to dataset\accident_data.csv (links in dataset\README.md)
python -m src.eda
python -m src.train
python -m src.build_docs
uvicorn api.main:app --reload --port 8000      # terminal 1
streamlit run frontend/app.py                  # terminal 2
pytest
```
API docs: http://127.0.0.1:8000/docs - Dashboard: http://localhost:8501
